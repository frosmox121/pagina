
import { prisma } from '@/lib/db'
import { createActivity } from './activity'

export interface AchievementCondition {
  type: 'exercises_completed' | 'points_earned' | 'streak_days' | 'games_played' | 'courses_completed'
  value: number
  language?: string
}

export async function checkAndUnlockAchievements(userId: string) {
  try {
    // Get user stats
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        submissions: true,
        gameScores: true,
        userProgress: true,
        userAchievements: {
          include: { achievement: true }
        }
      }
    })

    if (!user) return

    // Get all achievements user hasn't unlocked yet
    const unlockedAchievementIds = user.userAchievements.map(ua => ua.achievementId)
    const availableAchievements = await prisma.achievement.findMany({
      where: {
        isActive: true,
        id: { notIn: unlockedAchievementIds }
      }
    })

    for (const achievement of availableAchievements) {
      const condition = achievement.condition as unknown as AchievementCondition
      let shouldUnlock = false

      switch (condition.type) {
        case 'exercises_completed':
          const completedExercises = user.submissions.filter(s => s.status === 'passed').length
          shouldUnlock = completedExercises >= condition.value
          break

        case 'points_earned':
          shouldUnlock = user.totalPoints >= condition.value
          break

        case 'games_played':
          shouldUnlock = user.gameScores.length >= condition.value
          break

        case 'courses_completed':
          const completedCourses = user.userProgress.filter(up => up.progress >= 100).length
          shouldUnlock = completedCourses >= condition.value
          break
      }

      if (shouldUnlock) {
        await unlockAchievement(userId, achievement.id)
      }
    }
  } catch (error) {
    console.error('Error checking achievements:', error)
  }
}

export async function unlockAchievement(userId: string, achievementId: string) {
  try {
    const achievement = await prisma.achievement.findUnique({
      where: { id: achievementId }
    })

    if (!achievement) return

    // Create user achievement
    await prisma.userAchievement.create({
      data: {
        userId,
        achievementId,
        progress: 100
      }
    })

    // Update user points
    await prisma.user.update({
      where: { id: userId },
      data: {
        totalPoints: { increment: achievement.points }
      }
    })

    // Create activity
    await createActivity({
      userId,
      type: 'achievement_unlocked',
      title: `¡Logro desbloqueado: ${achievement.title}!`,
      description: achievement.description,
      metadata: {
        achievementId,
        points: achievement.points,
        rarity: achievement.rarity
      }
    })

    return true
  } catch (error) {
    console.error('Error unlocking achievement:', error)
    return false
  }
}
