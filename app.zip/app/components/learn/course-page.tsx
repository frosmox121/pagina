
'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { 
  BookOpen, 
  Play, 
  CheckCircle, 
  Clock,
  Users,
  Star,
  ChevronRight,
  Award,
  Target,
  ArrowLeft
} from 'lucide-react'
import { motion } from 'framer-motion'
import Link from 'next/link'

interface Course {
  id: string
  title: string
  description: string
  language: string
  difficulty: string
  imageUrl?: string
  progress: number
  isEnrolled: boolean
  modules: Module[]
}

interface Module {
  id: string
  title: string
  content: string
  videoUrl?: string
  orderIndex: number
  isCompleted: boolean
}

interface CoursePageProps {
  courseId: string
}

export function CoursePage({ courseId }: CoursePageProps) {
  const { data: session } = useSession()
  const [course, setCourse] = useState<Course | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [enrolling, setEnrolling] = useState(false)

  useEffect(() => {
    fetchCourse()
  }, [courseId])

  const fetchCourse = async () => {
    try {
      setIsLoading(true)
      const response = await fetch(`/api/learn/course/${courseId}`)
      if (response.ok) {
        const data = await response.json()
        setCourse(data.course)
      }
    } catch (error) {
      console.error('Error fetching course:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleEnroll = async () => {
    try {
      setEnrolling(true)
      const response = await fetch(`/api/learn/course/${courseId}/enroll`, {
        method: 'POST'
      })
      if (response.ok) {
        fetchCourse() // Refresh course data
      }
    } catch (error) {
      console.error('Error enrolling:', error)
    } finally {
      setEnrolling(false)
    }
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'bg-green-500'
      case 'intermediate': return 'bg-yellow-500'
      case 'advanced': return 'bg-red-500'
      default: return 'bg-gray-500'
    }
  }

  const getDifficultyLabel = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'Principiante'
      case 'intermediate': return 'Intermedio'
      case 'advanced': return 'Avanzado'
      default: return difficulty
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!course) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Curso no encontrado</h1>
          <Button asChild>
            <Link href="/learn">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Volver a Cursos
            </Link>
          </Button>
        </div>
      </div>
    )
  }

  const completedModules = course.modules.filter(m => m.isCompleted).length
  const totalModules = course.modules.length

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Back Button */}
        <div className="mb-6">
          <Button variant="ghost" asChild>
            <Link href="/learn">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Volver a Cursos
            </Link>
          </Button>
        </div>

        {/* Course Header */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2, duration: 0.6 }}
            >
              <h1 className="text-3xl font-bold tracking-tight mb-4">
                {course.title}
              </h1>
              <p className="text-lg text-muted-foreground mb-6">
                {course.description}
              </p>
              
              <div className="flex items-center gap-4 mb-6">
                <Badge className={`${getDifficultyColor(course.difficulty)} text-white`}>
                  {getDifficultyLabel(course.difficulty)}
                </Badge>
                <Badge variant="outline">
                  {course.language.toUpperCase()}
                </Badge>
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <BookOpen className="h-4 w-4" />
                  {totalModules} módulos
                </div>
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  ~2h total
                </div>
              </div>

              {course.isEnrolled && (
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Progreso del Curso</span>
                    <span className="text-sm text-muted-foreground">
                      {completedModules}/{totalModules} módulos
                    </span>
                  </div>
                  <Progress value={course.progress} className="h-3" />
                  <p className="text-sm text-muted-foreground mt-1">
                    {course.progress}% completado
                  </p>
                </div>
              )}
            </motion.div>
          </div>

          <div className="lg:col-span-1">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5" />
                    {course.isEnrolled ? 'Continuar Aprendiendo' : 'Comenzar Curso'}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {course.isEnrolled ? (
                    <div className="space-y-4">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-primary">{course.progress}%</div>
                        <div className="text-sm text-muted-foreground">Completado</div>
                      </div>
                      <Button className="w-full" asChild>
                        <Link href={`/learn/course/${course.id}/module/${course.modules[0]?.id}`}>
                          <Play className="mr-2 h-4 w-4" />
                          Continuar
                        </Link>
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="text-center">
                        <BookOpen className="h-12 w-12 mx-auto mb-2 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">
                          Inscríbete para comenzar este curso
                        </p>
                      </div>
                      <Button 
                        className="w-full" 
                        onClick={handleEnroll}
                        disabled={enrolling}
                      >
                        {enrolling ? 'Inscribiendo...' : 'Inscribirse Gratis'}
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>

        {/* Course Modules */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                Contenido del Curso
              </CardTitle>
              <CardDescription>
                {totalModules} módulos • Aprende a tu propio ritmo
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {course.modules.map((module, index) => (
                  <motion.div
                    key={module.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.1 * index, duration: 0.3 }}
                  >
                    <div className="flex items-center justify-between p-4 rounded-lg border hover:bg-muted/50 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-muted text-sm font-medium">
                          {index + 1}
                        </div>
                        <div>
                          <h4 className="font-medium">{module.title}</h4>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Clock className="h-3 w-3" />
                            ~15 min
                            {module.videoUrl && (
                              <>
                                <span>•</span>
                                <Play className="h-3 w-3" />
                                Video
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {module.isCompleted && (
                          <CheckCircle className="h-5 w-5 text-green-500" />
                        )}
                        {course.isEnrolled ? (
                          <Button variant="ghost" size="sm" asChild>
                            <Link href={`/learn/course/${course.id}/module/${module.id}`}>
                              <ChevronRight className="h-4 w-4" />
                            </Link>
                          </Button>
                        ) : (
                          <Button variant="ghost" size="sm" disabled>
                            <ChevronRight className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Course Stats */}
        {course.isEnrolled && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.6 }}
            className="mt-8"
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  Tu Progreso
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold">{completedModules}</div>
                    <div className="text-sm text-muted-foreground">Módulos Completados</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{course.progress}%</div>
                    <div className="text-sm text-muted-foreground">Progreso Total</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">~{Math.round(completedModules * 0.25)}h</div>
                    <div className="text-sm text-muted-foreground">Tiempo Estudiado</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{course.progress >= 100 ? '1' : '0'}</div>
                    <div className="text-sm text-muted-foreground">Certificados</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </motion.div>
    </div>
  )
}
