
'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Separator } from '@/components/ui/separator'
import { Badge } from '@/components/ui/badge'
import {
  Settings,
  User,
  Bell,
  Shield,
  Palette,
  Globe,
  Save,
  Trash2,
  AlertTriangle
} from 'lucide-react'
import { motion } from 'framer-motion'
import { useToast } from '@/hooks/use-toast'

export function SettingsPage() {
  const { data: session } = useSession()
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)
  const [userStats, setUserStats] = useState({
    exercisesCompleted: 0,
    achievementsUnlocked: 0,
    daysActive: 0,
    totalPoints: 0,
    country: 'Argentina'
  })
  
  // Profile settings
  const [name, setName] = useState(session?.user?.name || '')
  const [email, setEmail] = useState(session?.user?.email || '')
  const [country, setCountry] = useState('Argentina')
  
  // Notification settings
  const [emailNotifications, setEmailNotifications] = useState(true)
  const [achievementNotifications, setAchievementNotifications] = useState(true)
  const [practiceReminders, setPracticeReminders] = useState(false)
  
  // Appearance settings
  const [theme, setTheme] = useState('dark')
  const [language, setLanguage] = useState('es')
  
  // Privacy settings
  const [profilePublic, setProfilePublic] = useState(true)
  const [showRanking, setShowRanking] = useState(true)

  useEffect(() => {
    if (session?.user) {
      fetchUserStats()
      // Set initial profile values
      setName(session.user.name || '')
      setEmail(session.user.email || '')
    }
  }, [session])

  const fetchUserStats = async () => {
    try {
      // Fetch user general stats
      const statsResponse = await fetch('/api/user/stats')
      if (statsResponse.ok) {
        const statsData = await statsResponse.json()
        setUserStats(prev => ({
          ...prev,
          totalPoints: statsData.totalPoints || 0,
          country: statsData.country || 'Argentina'
        }))
        setCountry(statsData.country || 'Argentina')
      }

      // Fetch exercises completed
      const practiceResponse = await fetch('/api/practice/stats')
      if (practiceResponse.ok) {
        const practiceData = await practiceResponse.json()
        setUserStats(prev => ({
          ...prev,
          exercisesCompleted: practiceData.exercisesCompleted || 0
        }))
      }

      // Fetch achievements
      const achievementsResponse = await fetch('/api/user/achievements')
      if (achievementsResponse.ok) {
        const achievementsData = await achievementsResponse.json()
        setUserStats(prev => ({
          ...prev,
          achievementsUnlocked: achievementsData.achievements?.length || 0
        }))
      }

      // Calculate days active (basic calculation)
      if (session?.user) {
        const userResponse = await fetch('/api/user/profile-stats')
        if (userResponse.ok) {
          const userData = await userResponse.json()
          setUserStats(prev => ({
            ...prev,
            daysActive: userData.daysActive || 0
          }))
        }
      }
    } catch (error) {
      console.error('Error fetching user stats:', error)
    }
  }

  const handleSaveProfile = async () => {
    setLoading(true)
    try {
      const response = await fetch('/api/user/update-profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name,
          email,
          country
        }),
      })

      const data = await response.json()

      if (response.ok) {
        toast({
          title: "Perfil actualizado",
          description: "Tus cambios han sido guardados exitosamente.",
        })
        // Update local stats
        setUserStats(prev => ({
          ...prev,
          country: data.user.country
        }))
      } else {
        toast({
          title: "Error",
          description: data.error || "No se pudieron guardar los cambios.",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error('Error saving profile:', error)
      toast({
        title: "Error",
        description: "No se pudieron guardar los cambios.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleDeleteAccount = async () => {
    if (confirm('¿Estás seguro de que quieres eliminar tu cuenta? Esta acción no se puede deshacer.')) {
      toast({
        title: "Función no disponible",
        description: "La eliminación de cuenta estará disponible próximamente.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <div className="h-12 w-12 rounded-2xl bg-primary flex items-center justify-center">
            <Settings className="h-6 w-6 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Configuración</h1>
            <p className="text-muted-foreground">
              Personaliza tu experiencia en DevTools
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Navigation */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Secciones</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button variant="ghost" className="w-full justify-start">
                  <User className="mr-2 h-4 w-4" />
                  Perfil
                </Button>
                <Button variant="ghost" className="w-full justify-start">
                  <Bell className="mr-2 h-4 w-4" />
                  Notificaciones
                </Button>
                <Button variant="ghost" className="w-full justify-start">
                  <Palette className="mr-2 h-4 w-4" />
                  Apariencia
                </Button>
                <Button variant="ghost" className="w-full justify-start">
                  <Shield className="mr-2 h-4 w-4" />
                  Privacidad
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Profile Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Información del Perfil
                </CardTitle>
                <CardDescription>
                  Actualiza tu información personal
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nombre</Label>
                    <Input
                      id="name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Tu nombre completo"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="tu@email.com"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="country">País</Label>
                  <Select value={country} onValueChange={setCountry}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Argentina">Argentina</SelectItem>
                      <SelectItem value="México">México</SelectItem>
                      <SelectItem value="España">España</SelectItem>
                      <SelectItem value="Colombia">Colombia</SelectItem>
                      <SelectItem value="Chile">Chile</SelectItem>
                      <SelectItem value="Perú">Perú</SelectItem>
                      <SelectItem value="Uruguay">Uruguay</SelectItem>
                      <SelectItem value="Venezuela">Venezuela</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button onClick={handleSaveProfile} disabled={loading}>
                  <Save className="mr-2 h-4 w-4" />
                  {loading ? 'Guardando...' : 'Guardar Cambios'}
                </Button>
              </CardContent>
            </Card>

            {/* Notification Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="h-5 w-5" />
                  Notificaciones
                </CardTitle>
                <CardDescription>
                  Configura qué notificaciones quieres recibir
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Notificaciones por Email</Label>
                    <p className="text-sm text-muted-foreground">
                      Recibe actualizaciones importantes por email
                    </p>
                  </div>
                  <Switch
                    checked={emailNotifications}
                    onCheckedChange={setEmailNotifications}
                  />
                </div>

                <Separator />

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Logros Desbloqueados</Label>
                    <p className="text-sm text-muted-foreground">
                      Notificaciones cuando desbloquees nuevos logros
                    </p>
                  </div>
                  <Switch
                    checked={achievementNotifications}
                    onCheckedChange={setAchievementNotifications}
                  />
                </div>

                <Separator />

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Recordatorios de Práctica</Label>
                    <p className="text-sm text-muted-foreground">
                      Recordatorios diarios para mantener tu racha
                    </p>
                  </div>
                  <Switch
                    checked={practiceReminders}
                    onCheckedChange={setPracticeReminders}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Appearance Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Palette className="h-5 w-5" />
                  Apariencia
                </CardTitle>
                <CardDescription>
                  Personaliza la apariencia de la aplicación
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="theme">Tema</Label>
                    <Select value={theme} onValueChange={setTheme}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="light">Claro</SelectItem>
                        <SelectItem value="dark">Oscuro</SelectItem>
                        <SelectItem value="system">Sistema</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="language">Idioma</Label>
                    <Select value={language} onValueChange={setLanguage}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="es">Español</SelectItem>
                        <SelectItem value="en">English</SelectItem>
                        <SelectItem value="pt">Português</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Privacy Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  Privacidad
                </CardTitle>
                <CardDescription>
                  Controla la visibilidad de tu información
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Perfil Público</Label>
                    <p className="text-sm text-muted-foreground">
                      Permite que otros usuarios vean tu perfil
                    </p>
                  </div>
                  <Switch
                    checked={profilePublic}
                    onCheckedChange={setProfilePublic}
                  />
                </div>

                <Separator />

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Mostrar en Ranking</Label>
                    <p className="text-sm text-muted-foreground">
                      Aparecer en las tablas de clasificación globales
                    </p>
                  </div>
                  <Switch
                    checked={showRanking}
                    onCheckedChange={setShowRanking}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Account Stats */}
            <Card>
              <CardHeader>
                <CardTitle>Estadísticas de la Cuenta</CardTitle>
                <CardDescription>
                  Información sobre tu actividad en DevTools
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold">{userStats.exercisesCompleted}</div>
                    <div className="text-sm text-muted-foreground">Ejercicios</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{userStats.achievementsUnlocked}</div>
                    <div className="text-sm text-muted-foreground">Logros</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{userStats.daysActive}</div>
                    <div className="text-sm text-muted-foreground">Días activo</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{userStats.totalPoints}</div>
                    <div className="text-sm text-muted-foreground">Puntos</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Danger Zone */}
            <Card className="border-destructive">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-destructive">
                  <AlertTriangle className="h-5 w-5" />
                  Zona de Peligro
                </CardTitle>
                <CardDescription>
                  Acciones irreversibles en tu cuenta
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button 
                  variant="destructive" 
                  onClick={handleDeleteAccount}
                  className="w-full md:w-auto"
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Eliminar Cuenta
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </motion.div>
    </div>
  )
}
