

'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { 
  User, 
  Calendar, 
  MapPin, 
  Trophy, 
  Star, 
  MessageSquare, 
  Code, 
  Award,
  ArrowLeft,
  Mail,
  Crown
} from 'lucide-react'
import { motion } from 'framer-motion'
import Link from 'next/link'

interface UserProfileData {
  id: string
  name: string
  image?: string
  email?: string
  level: number
  totalPoints: number
  practicePoints: number
  country: string
  rank: number
  joinedAt: string
  lastActive: string
  stats: {
    forumTopics: number
    forumPosts: number
    gamesPlayed: number
    achievements: number
    exercisesCompleted: number
  }
  recentActivity: {
    topics: Array<{
      id: string
      title: string
      category: {
        name: string
        color: string
      }
      createdAt: string
    }>
    achievements: Array<{
      id: string
      achievement: {
        title: string
        description: string
        icon: string
        rarity: string
      }
      unlockedAt: string
    }>
  }
}

interface UserProfileProps {
  userId: string
}

export function UserProfile({ userId }: UserProfileProps) {
  const [userData, setUserData] = useState<UserProfileData | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (userId) {
      fetchUserProfile()
    }
  }, [userId])

  const fetchUserProfile = async () => {
    try {
      setIsLoading(true)
      const response = await fetch(`/api/user/profile/${userId}`)
      if (response.ok) {
        const data = await response.json()
        setUserData(data.user)
      } else {
        const errorData = await response.json()
        setError(errorData.error || 'No se pudo cargar el perfil')
      }
    } catch (error) {
      console.error('Error fetching user profile:', error)
      setError('Error de conexión')
    } finally {
      setIsLoading(false)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('es-ES', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })
  }

  const getTimeAgo = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24))
    
    if (diffInDays === 0) return 'Hoy'
    if (diffInDays === 1) return 'Ayer'
    if (diffInDays < 7) return `Hace ${diffInDays} días`
    if (diffInDays < 30) return `Hace ${Math.floor(diffInDays / 7)} semanas`
    return `Hace ${Math.floor(diffInDays / 30)} meses`
  }

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'legendary': return 'text-yellow-500'
      case 'epic': return 'text-purple-500'
      case 'rare': return 'text-blue-500'
      default: return 'text-gray-500'
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (error || !userData) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-4xl text-center">
        <h1 className="text-2xl font-bold mb-4">{error || 'Perfil no encontrado'}</h1>
        <Button asChild>
          <Link href="/forum">Volver al Foro</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Back Button */}
        <Button variant="outline" onClick={() => window.history.back()} className="mb-6">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Volver
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Profile Info */}
          <div className="lg:col-span-1">
            <Card>
              <CardContent className="p-6 text-center">
                <Avatar className="h-24 w-24 mx-auto mb-4">
                  <AvatarImage src={userData.image} />
                  <AvatarFallback className="text-2xl">
                    {userData.name.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                
                <h1 className="text-2xl font-bold mb-2">{userData.name}</h1>
                
                <div className="flex items-center justify-center gap-2 mb-4">
                  <Badge className="flex items-center gap-1">
                    <Crown className="h-3 w-3" />
                    Nivel {userData.level}
                  </Badge>
                  <Badge variant="outline">
                    #{userData.rank} Global
                  </Badge>
                </div>

                {userData.email && (
                  <div className="flex items-center justify-center gap-2 mb-2 text-sm text-muted-foreground">
                    <Mail className="h-4 w-4" />
                    <span>{userData.email}</span>
                  </div>
                )}

                <div className="flex items-center justify-center gap-2 mb-2 text-sm text-muted-foreground">
                  <MapPin className="h-4 w-4" />
                  <span>{userData.country}</span>
                </div>

                <div className="flex items-center justify-center gap-2 mb-4 text-sm text-muted-foreground">
                  <Calendar className="h-4 w-4" />
                  <span>Miembro desde {formatDate(userData.joinedAt)}</span>
                </div>

                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">{userData.totalPoints}</div>
                  <div className="text-sm text-muted-foreground">Puntos Totales</div>
                </div>
              </CardContent>
            </Card>

            {/* Stats */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="text-lg">Estadísticas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-3 bg-muted rounded-lg">
                    <div className="text-xl font-bold text-blue-500">{userData.stats.forumTopics}</div>
                    <div className="text-xs text-muted-foreground">Temas</div>
                  </div>
                  <div className="text-center p-3 bg-muted rounded-lg">
                    <div className="text-xl font-bold text-green-500">{userData.stats.forumPosts}</div>
                    <div className="text-xs text-muted-foreground">Posts</div>
                  </div>
                  <div className="text-center p-3 bg-muted rounded-lg">
                    <div className="text-xl font-bold text-purple-500">{userData.stats.exercisesCompleted}</div>
                    <div className="text-xs text-muted-foreground">Ejercicios</div>
                  </div>
                  <div className="text-center p-3 bg-muted rounded-lg">
                    <div className="text-xl font-bold text-yellow-500">{userData.stats.achievements}</div>
                    <div className="text-xs text-muted-foreground">Logros</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Activity */}
          <div className="lg:col-span-2 space-y-6">
            {/* Recent Topics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  Temas Recientes
                </CardTitle>
              </CardHeader>
              <CardContent>
                {userData.recentActivity.topics.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">
                    No ha creado temas aún
                  </div>
                ) : (
                  <div className="space-y-3">
                    {userData.recentActivity.topics.map((topic) => (
                      <div key={topic.id} className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                        <div 
                          className="w-3 h-3 rounded-full flex-shrink-0"
                          style={{ backgroundColor: topic.category.color }}
                        />
                        <div className="flex-1">
                          <Link 
                            href={`/forum/topic/${topic.id}`}
                            className="font-medium hover:text-primary transition-colors line-clamp-1"
                          >
                            {topic.title}
                          </Link>
                          <div className="text-xs text-muted-foreground">
                            {topic.category.name} • {getTimeAgo(topic.createdAt)}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Recent Achievements */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  Logros Recientes
                </CardTitle>
              </CardHeader>
              <CardContent>
                {userData.recentActivity.achievements.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">
                    No ha desbloqueado logros aún
                  </div>
                ) : (
                  <div className="space-y-3">
                    {userData.recentActivity.achievements.map((userAchievement) => (
                      <div key={userAchievement.id} className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                        <div className={`text-2xl ${getRarityColor(userAchievement.achievement.rarity)}`}>
                          {userAchievement.achievement.icon}
                        </div>
                        <div className="flex-1">
                          <div className="font-medium">{userAchievement.achievement.title}</div>
                          <div className="text-sm text-muted-foreground">
                            {userAchievement.achievement.description}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            Desbloqueado {getTimeAgo(userAchievement.unlockedAt)}
                          </div>
                        </div>
                        <Badge variant="outline" className={getRarityColor(userAchievement.achievement.rarity)}>
                          {userAchievement.achievement.rarity}
                        </Badge>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </motion.div>
    </div>
  )
}
