
'use client'

import { useSession } from 'next-auth/react'
import { UserDashboard } from '@/components/user-dashboard'
import { useEffect, useState } from 'react'

interface UserStats {
  level: number
  totalPoints: number
  practicePoints: number
  country: string
  rank: number
}

export function DashboardWrapper() {
  const { data: session } = useSession()
  const [userStats, setUserStats] = useState<UserStats | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchUserStats = async () => {
      try {
        const response = await fetch('/api/user/stats')
        if (response.ok) {
          const data = await response.json()
          setUserStats(data)
        }
      } catch (error) {
        console.error('Error fetching user stats:', error)
      } finally {
        setIsLoading(false)
      }
    }

    if (session?.user) {
      fetchUserStats()
    } else {
      setIsLoading(false)
    }
  }, [session])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  return <UserDashboard userStats={userStats} />
}
