
'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Circle,
  Play,
  Pause,
  ArrowUp,
  ArrowDown,
  Trophy,
  Target,
  Zap,
  ArrowLeft
} from 'lucide-react'
import { motion } from 'framer-motion'
import Link from 'next/link'
import { useToast } from '@/hooks/use-toast'

interface Ball {
  x: number
  y: number
  dx: number
  dy: number
  speed: number
}

interface Paddle {
  x: number
  y: number
  width: number
  height: number
  speed: number
}

interface GameState {
  playerScore: number
  aiScore: number
  isPlaying: boolean
  isPaused: boolean
  gameOver: boolean
  winner: 'player' | 'ai' | null
}

const CANVAS_WIDTH = 800
const CANVAS_HEIGHT = 400
const PADDLE_WIDTH = 10
const PADDLE_HEIGHT = 80
const BALL_SIZE = 10
const WINNING_SCORE = 5

export function PongGame() {
  const { data: session } = useSession()
  const { toast } = useToast()
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animationRef = useRef<number>()
  
  const [gameState, setGameState] = useState<GameState>({
    playerScore: 0,
    aiScore: 0,
    isPlaying: false,
    isPaused: false,
    gameOver: false,
    winner: null
  })

  const [ball, setBall] = useState<Ball>({
    x: CANVAS_WIDTH / 2,
    y: CANVAS_HEIGHT / 2,
    dx: 5,
    dy: 3,
    speed: 5
  })

  const [playerPaddle, setPlayerPaddle] = useState<Paddle>({
    x: 20,
    y: CANVAS_HEIGHT / 2 - PADDLE_HEIGHT / 2,
    width: PADDLE_WIDTH,
    height: PADDLE_HEIGHT,
    speed: 8
  })

  const [aiPaddle, setAiPaddle] = useState<Paddle>({
    x: CANVAS_WIDTH - 30,
    y: CANVAS_HEIGHT / 2 - PADDLE_HEIGHT / 2,
    width: PADDLE_WIDTH,
    height: PADDLE_HEIGHT,
    speed: 6
  })

  const [keys, setKeys] = useState<Set<string>>(new Set())

  const resetBall = useCallback(() => {
    setBall({
      x: CANVAS_WIDTH / 2,
      y: CANVAS_HEIGHT / 2,
      dx: Math.random() > 0.5 ? 5 : -5,
      dy: (Math.random() - 0.5) * 6,
      speed: 5
    })
  }, [])

  const startGame = () => {
    setGameState({
      playerScore: 0,
      aiScore: 0,
      isPlaying: true,
      isPaused: false,
      gameOver: false,
      winner: null
    })
    
    setPlayerPaddle(prev => ({
      ...prev,
      y: CANVAS_HEIGHT / 2 - PADDLE_HEIGHT / 2
    }))
    
    setAiPaddle(prev => ({
      ...prev,
      y: CANVAS_HEIGHT / 2 - PADDLE_HEIGHT / 2
    }))
    
    resetBall()
  }

  const pauseGame = () => {
    setGameState(prev => ({ ...prev, isPaused: !prev.isPaused }))
  }

  const resetGame = () => {
    setGameState({
      playerScore: 0,
      aiScore: 0,
      isPlaying: false,
      isPaused: false,
      gameOver: false,
      winner: null
    })
    resetBall()
  }

  const saveScore = async (finalScore: number) => {
    try {
      await fetch('/api/games/save-score', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          gameType: 'pong',
          score: finalScore,
          level: 1
        }),
      })
      
      toast({
        title: "Puntuación Guardada",
        description: `Tu puntuación de ${finalScore} ha sido guardada.`,
      })
    } catch (error) {
      console.error('Error saving score:', error)
    }
  }

  // Collision detection
  const checkCollision = useCallback((rect1: any, rect2: any) => {
    return rect1.x < rect2.x + rect2.width &&
           rect1.x + rect1.width > rect2.x &&
           rect1.y < rect2.y + rect2.height &&
           rect1.y + rect1.height > rect2.y
  }, [])

  // Game update logic
  const updateGame = useCallback(() => {
    if (!gameState.isPlaying || gameState.isPaused || gameState.gameOver) return

    setBall(prevBall => {
      let newBall = { ...prevBall }

      // Update ball position
      newBall.x += newBall.dx
      newBall.y += newBall.dy

      // Ball collision with top and bottom walls
      if (newBall.y <= 0 || newBall.y >= CANVAS_HEIGHT - BALL_SIZE) {
        newBall.dy = -newBall.dy
      }

      // Ball collision with paddles
      const ballRect = { x: newBall.x, y: newBall.y, width: BALL_SIZE, height: BALL_SIZE }
      const playerRect = { x: playerPaddle.x, y: playerPaddle.y, width: playerPaddle.width, height: playerPaddle.height }
      const aiRect = { x: aiPaddle.x, y: aiPaddle.y, width: aiPaddle.width, height: aiPaddle.height }

      if (checkCollision(ballRect, playerRect) && newBall.dx < 0) {
        newBall.dx = -newBall.dx
        newBall.speed = Math.min(newBall.speed + 0.5, 10)
        // Add some randomness to ball direction based on where it hit the paddle
        const hitPos = (newBall.y - playerPaddle.y) / playerPaddle.height
        newBall.dy = (hitPos - 0.5) * 8
      }

      if (checkCollision(ballRect, aiRect) && newBall.dx > 0) {
        newBall.dx = -newBall.dx
        newBall.speed = Math.min(newBall.speed + 0.5, 10)
        const hitPos = (newBall.y - aiPaddle.y) / aiPaddle.height
        newBall.dy = (hitPos - 0.5) * 8
      }

      // Ball out of bounds - scoring
      if (newBall.x < 0) {
        setGameState(prev => {
          const newAiScore = prev.aiScore + 1
          if (newAiScore >= WINNING_SCORE) {
            saveScore(prev.playerScore)
            return {
              ...prev,
              aiScore: newAiScore,
              gameOver: true,
              winner: 'ai',
              isPlaying: false
            }
          }
          return { ...prev, aiScore: newAiScore }
        })
        resetBall()
        return prevBall
      }

      if (newBall.x > CANVAS_WIDTH) {
        setGameState(prev => {
          const newPlayerScore = prev.playerScore + 1
          if (newPlayerScore >= WINNING_SCORE) {
            saveScore(newPlayerScore)
            return {
              ...prev,
              playerScore: newPlayerScore,
              gameOver: true,
              winner: 'player',
              isPlaying: false
            }
          }
          return { ...prev, playerScore: newPlayerScore }
        })
        resetBall()
        return prevBall
      }

      return newBall
    })

    // Update player paddle
    setPlayerPaddle(prev => {
      let newY = prev.y
      if (keys.has('ArrowUp') || keys.has('w')) {
        newY = Math.max(0, prev.y - prev.speed)
      }
      if (keys.has('ArrowDown') || keys.has('s')) {
        newY = Math.min(CANVAS_HEIGHT - prev.height, prev.y + prev.speed)
      }
      return { ...prev, y: newY }
    })

    // Update AI paddle (simple AI)
    setAiPaddle(prev => {
      const paddleCenter = prev.y + prev.height / 2
      const ballCenter = ball.y + BALL_SIZE / 2
      const diff = ballCenter - paddleCenter
      
      let newY = prev.y
      if (Math.abs(diff) > 10) {
        if (diff > 0) {
          newY = Math.min(CANVAS_HEIGHT - prev.height, prev.y + prev.speed * 0.8)
        } else {
          newY = Math.max(0, prev.y - prev.speed * 0.8)
        }
      }
      
      return { ...prev, y: newY }
    })
  }, [gameState, ball, playerPaddle, aiPaddle, keys, checkCollision, resetBall, saveScore])

  // Draw game
  const draw = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    // Clear canvas
    ctx.fillStyle = '#000000'
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT)

    // Draw center line
    ctx.setLineDash([5, 5])
    ctx.strokeStyle = '#ffffff'
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(CANVAS_WIDTH / 2, 0)
    ctx.lineTo(CANVAS_WIDTH / 2, CANVAS_HEIGHT)
    ctx.stroke()
    ctx.setLineDash([])

    // Draw paddles
    ctx.fillStyle = '#ffffff'
    ctx.fillRect(playerPaddle.x, playerPaddle.y, playerPaddle.width, playerPaddle.height)
    ctx.fillRect(aiPaddle.x, aiPaddle.y, aiPaddle.width, aiPaddle.height)

    // Draw ball
    ctx.fillStyle = '#ffffff'
    ctx.fillRect(ball.x, ball.y, BALL_SIZE, BALL_SIZE)

    // Draw scores
    ctx.font = '48px Arial'
    ctx.textAlign = 'center'
    ctx.fillText(gameState.playerScore.toString(), CANVAS_WIDTH / 4, 60)
    ctx.fillText(gameState.aiScore.toString(), (3 * CANVAS_WIDTH) / 4, 60)

    // Draw game over message
    if (gameState.gameOver) {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.8)'
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT)
      
      ctx.fillStyle = '#ffffff'
      ctx.font = '36px Arial'
      ctx.textAlign = 'center'
      const message = gameState.winner === 'player' ? '¡Ganaste!' : '¡Perdiste!'
      ctx.fillText(message, CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 - 20)
      
      ctx.font = '24px Arial'
      ctx.fillText('Presiona JUGAR para comenzar de nuevo', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 + 20)
    }

    if (gameState.isPaused && !gameState.gameOver) {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.5)'
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT)
      
      ctx.fillStyle = '#ffffff'
      ctx.font = '36px Arial'
      ctx.textAlign = 'center'
      ctx.fillText('PAUSADO', CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2)
    }
  }, [ball, playerPaddle, aiPaddle, gameState])

  // Game loop
  useEffect(() => {
    const gameLoop = () => {
      updateGame()
      draw()
      animationRef.current = requestAnimationFrame(gameLoop)
    }

    if (gameState.isPlaying) {
      animationRef.current = requestAnimationFrame(gameLoop)
    }

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [gameState.isPlaying, updateGame, draw])

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      setKeys(prev => new Set(prev).add(e.key))
    }

    const handleKeyUp = (e: KeyboardEvent) => {
      setKeys(prev => {
        const newKeys = new Set(prev)
        newKeys.delete(e.key)
        return newKeys
      })
    }

    window.addEventListener('keydown', handleKeyDown)
    window.addEventListener('keyup', handleKeyUp)

    return () => {
      window.removeEventListener('keydown', handleKeyDown)
      window.removeEventListener('keyup', handleKeyUp)
    }
  }, [])

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-2xl bg-green-500 flex items-center justify-center">
              <Circle className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            Pong
          </h1>
          <p className="text-lg text-muted-foreground">
            El clásico juego de ping pong. Primero en llegar a 5 puntos gana
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Game Canvas */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Mesa de Juego</span>
                  <div className="flex items-center gap-2">
                    {!gameState.isPlaying ? (
                      <Button onClick={startGame}>
                        <Play className="mr-2 h-4 w-4" />
                        Jugar
                      </Button>
                    ) : (
                      <>
                        <Button variant="outline" onClick={pauseGame}>
                          {gameState.isPaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
                        </Button>
                        <Button variant="outline" onClick={resetGame}>
                          Reiniciar
                        </Button>
                      </>
                    )}
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-center">
                  <canvas
                    ref={canvasRef}
                    width={CANVAS_WIDTH}
                    height={CANVAS_HEIGHT}
                    className="border-2 border-gray-700 bg-black"
                    style={{ maxWidth: '100%', height: 'auto' }}
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Game Info */}
          <div className="lg:col-span-1 space-y-6">
            {/* Score */}
            <Card>
              <CardHeader>
                <CardTitle>Puntuación</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-medium">Jugador</span>
                    <Badge variant="default" className="text-lg px-3 py-1">
                      {gameState.playerScore}
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-medium">IA</span>
                    <Badge variant="secondary" className="text-lg px-3 py-1">
                      {gameState.aiScore}
                    </Badge>
                  </div>
                  <div className="text-center text-sm text-muted-foreground">
                    Primero en llegar a {WINNING_SCORE} gana
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Game Status */}
            <Card>
              <CardHeader>
                <CardTitle>Estado del Juego</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Estado:</span>
                    <Badge variant={
                      gameState.gameOver ? 'destructive' : 
                      gameState.isPlaying ? (gameState.isPaused ? 'secondary' : 'default') : 
                      'outline'
                    }>
                      {gameState.gameOver ? 'Terminado' :
                       gameState.isPlaying ? (gameState.isPaused ? 'Pausado' : 'Jugando') :
                       'Detenido'}
                    </Badge>
                  </div>
                  {gameState.winner && (
                    <div className="flex justify-between">
                      <span>Ganador:</span>
                      <Badge variant={gameState.winner === 'player' ? 'default' : 'secondary'}>
                        {gameState.winner === 'player' ? 'Jugador' : 'IA'}
                      </Badge>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span>Velocidad:</span>
                    <span className="text-sm">{ball.speed.toFixed(1)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Controls */}
            <Card>
              <CardHeader>
                <CardTitle>Controles</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-sm text-muted-foreground space-y-2">
                    <div className="flex items-center gap-2">
                      <kbd className="px-2 py-1 bg-muted rounded text-xs">↑</kbd>
                      <span>o</span>
                      <kbd className="px-2 py-1 bg-muted rounded text-xs">W</kbd>
                      <span>Mover hacia arriba</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <kbd className="px-2 py-1 bg-muted rounded text-xs">↓</kbd>
                      <span>o</span>
                      <kbd className="px-2 py-1 bg-muted rounded text-xs">S</kbd>
                      <span>Mover hacia abajo</span>
                    </div>
                  </div>
                  
                  <div className="text-xs text-muted-foreground">
                    <p>• La pelota acelera cada vez que toca una paleta</p>
                    <p>• El ángulo de rebote depende de dónde golpee la paleta</p>
                    <p>• La IA se vuelve más difícil conforme avanza el juego</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Back to Games */}
            <Card>
              <CardContent className="pt-6">
                <Button variant="outline" className="w-full" asChild>
                  <Link href="/games">
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Volver a Juegos
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </motion.div>
    </div>
  )
}
