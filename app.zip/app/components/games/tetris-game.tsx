
'use client'

import { useState, useEffect, useCallback } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Grid3x3,
  Play,
  Pause,
  RotateCw,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Trophy,
  Target,
  Zap,
  ArrowUp
} from 'lucide-react'
import { motion } from 'framer-motion'
import Link from 'next/link'
import { useToast } from '@/hooks/use-toast'

type Block = number
type Board = Block[][]
type Piece = {
  shape: Block[][]
  x: number
  y: number
  color: number
}

const BOARD_WIDTH = 10
const BOARD_HEIGHT = 20

const PIECES = [
  { shape: [[1, 1, 1, 1]], color: 1 }, // I
  { shape: [[1, 1], [1, 1]], color: 2 }, // O
  { shape: [[0, 1, 0], [1, 1, 1]], color: 3 }, // T
  { shape: [[0, 1, 1], [1, 1, 0]], color: 4 }, // S
  { shape: [[1, 1, 0], [0, 1, 1]], color: 5 }, // Z
  { shape: [[1, 0, 0], [1, 1, 1]], color: 6 }, // J
  { shape: [[0, 0, 1], [1, 1, 1]], color: 7 }  // L
]

const COLORS = [
  '#000000', // Empty
  '#00f0f0', // I - Cyan
  '#f0f000', // O - Yellow
  '#a000f0', // T - Purple
  '#00f000', // S - Green
  '#f00000', // Z - Red
  '#0000f0', // J - Blue
  '#f0a000'  // L - Orange
]

export function TetrisGame() {
  const { data: session } = useSession()
  const { toast } = useToast()
  
  const [board, setBoard] = useState<Board>(() => 
    Array(BOARD_HEIGHT).fill(null).map(() => Array(BOARD_WIDTH).fill(0))
  )
  const [currentPiece, setCurrentPiece] = useState<Piece | null>(null)
  const [nextPiece, setNextPiece] = useState<Piece | null>(null)
  const [score, setScore] = useState(0)
  const [lines, setLines] = useState(0)
  const [level, setLevel] = useState(1)
  const [isPlaying, setIsPlaying] = useState(false)
  const [isPaused, setIsPaused] = useState(false)
  const [gameOver, setGameOver] = useState(false)
  const [dropTime, setDropTime] = useState(1000)

  const createPiece = useCallback((): Piece => {
    const pieceTemplate = PIECES[Math.floor(Math.random() * PIECES.length)]
    return {
      shape: pieceTemplate.shape,
      x: Math.floor(BOARD_WIDTH / 2) - Math.floor(pieceTemplate.shape[0].length / 2),
      y: 0,
      color: pieceTemplate.color
    }
  }, [])

  const isValidMove = useCallback((piece: Piece, board: Board): boolean => {
    return piece.shape.every((row, dy) =>
      row.every((cell, dx) => {
        if (cell === 0) return true
        const newX = piece.x + dx
        const newY = piece.y + dy
        return (
          newX >= 0 &&
          newX < BOARD_WIDTH &&
          newY < BOARD_HEIGHT &&
          (newY < 0 || board[newY][newX] === 0)
        )
      })
    )
  }, [])

  const placePiece = useCallback((piece: Piece, board: Board): Board => {
    const newBoard = board.map(row => [...row])
    piece.shape.forEach((row, dy) => {
      row.forEach((cell, dx) => {
        if (cell !== 0) {
          const newY = piece.y + dy
          const newX = piece.x + dx
          if (newY >= 0) {
            newBoard[newY][newX] = piece.color
          }
        }
      })
    })
    return newBoard
  }, [])

  const clearLines = useCallback((board: Board): { newBoard: Board, linesCleared: number } => {
    const newBoard = board.filter(row => row.some(cell => cell === 0))
    const linesCleared = BOARD_HEIGHT - newBoard.length
    
    while (newBoard.length < BOARD_HEIGHT) {
      newBoard.unshift(Array(BOARD_WIDTH).fill(0))
    }
    
    return { newBoard, linesCleared }
  }, [])

  const rotatePiece = useCallback((piece: Piece): Piece => {
    const rotated = piece.shape[0].map((_, index) =>
      piece.shape.map(row => row[index]).reverse()
    )
    return { ...piece, shape: rotated }
  }, [])

  const movePiece = useCallback((direction: 'left' | 'right' | 'down' | 'rotate') => {
    if (!currentPiece || !isPlaying || isPaused || gameOver) return

    let newPiece = { ...currentPiece }

    switch (direction) {
      case 'left':
        newPiece.x -= 1
        break
      case 'right':
        newPiece.x += 1
        break
      case 'down':
        newPiece.y += 1
        break
      case 'rotate':
        newPiece = rotatePiece(currentPiece)
        break
    }

    if (isValidMove(newPiece, board)) {
      setCurrentPiece(newPiece)
    } else if (direction === 'down') {
      // Piece has landed
      const newBoard = placePiece(currentPiece, board)
      const { newBoard: clearedBoard, linesCleared } = clearLines(newBoard)
      
      setBoard(clearedBoard)
      setLines(prev => prev + linesCleared)
      setScore(prev => prev + (linesCleared * 100 * level))
      
      // Create new piece
      const newPiece = nextPiece || createPiece()
      const newNextPiece = createPiece()
      
      if (isValidMove(newPiece, clearedBoard)) {
        setCurrentPiece(newPiece)
        setNextPiece(newNextPiece)
      } else {
        // Game over
        setGameOver(true)
        setIsPlaying(false)
        saveScore()
      }
    }
  }, [currentPiece, board, isPlaying, isPaused, gameOver, isValidMove, placePiece, clearLines, rotatePiece, nextPiece, createPiece, level])

  const saveScore = async () => {
    try {
      await fetch('/api/games/save-score', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          gameType: 'tetris',
          score: score,
          level: level
        }),
      })
      
      toast({
        title: "Puntuación Guardada",
        description: `Tu puntuación de ${score} ha sido guardada.`,
      })
    } catch (error) {
      console.error('Error saving score:', error)
    }
  }

  const startGame = () => {
    const newBoard = Array(BOARD_HEIGHT).fill(null).map(() => Array(BOARD_WIDTH).fill(0))
    const firstPiece = createPiece()
    const secondPiece = createPiece()
    
    setBoard(newBoard)
    setCurrentPiece(firstPiece)
    setNextPiece(secondPiece)
    setScore(0)
    setLines(0)
    setLevel(1)
    setIsPlaying(true)
    setIsPaused(false)
    setGameOver(false)
  }

  const pauseGame = () => {
    setIsPaused(!isPaused)
  }

  const resetGame = () => {
    setIsPlaying(false)
    setIsPaused(false)
    setGameOver(false)
    setBoard(Array(BOARD_HEIGHT).fill(null).map(() => Array(BOARD_WIDTH).fill(0)))
    setCurrentPiece(null)
    setNextPiece(null)
    setScore(0)
    setLines(0)
    setLevel(1)
  }

  // Game loop
  useEffect(() => {
    if (!isPlaying || isPaused || gameOver) return

    const interval = setInterval(() => {
      movePiece('down')
    }, dropTime)

    return () => clearInterval(interval)
  }, [isPlaying, isPaused, gameOver, dropTime, movePiece])

  // Level progression
  useEffect(() => {
    const newLevel = Math.floor(lines / 10) + 1
    if (newLevel !== level) {
      setLevel(newLevel)
      setDropTime(1000 - (newLevel - 1) * 100)
    }
  }, [lines, level])

  // Keyboard controls
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (!isPlaying || isPaused || gameOver) return

      switch (e.key) {
        case 'ArrowLeft':
          e.preventDefault()
          movePiece('left')
          break
        case 'ArrowRight':
          e.preventDefault()
          movePiece('right')
          break
        case 'ArrowDown':
          e.preventDefault()
          movePiece('down')
          break
        case 'ArrowUp':
        case ' ':
          e.preventDefault()
          movePiece('rotate')
          break
      }
    }

    window.addEventListener('keydown', handleKeyPress)
    return () => window.removeEventListener('keydown', handleKeyPress)
  }, [isPlaying, isPaused, gameOver, movePiece])

  // Render board with current piece
  const renderBoard = () => {
    const displayBoard = board.map(row => [...row])
    
    if (currentPiece) {
      currentPiece.shape.forEach((row, dy) => {
        row.forEach((cell, dx) => {
          if (cell !== 0) {
            const newY = currentPiece.y + dy
            const newX = currentPiece.x + dx
            if (newY >= 0 && newY < BOARD_HEIGHT && newX >= 0 && newX < BOARD_WIDTH) {
              displayBoard[newY][newX] = currentPiece.color
            }
          }
        })
      })
    }
    
    return displayBoard
  }

  const displayBoard = renderBoard()

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-2xl bg-blue-500 flex items-center justify-center">
              <Grid3x3 className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            Tetris
          </h1>
          <p className="text-lg text-muted-foreground">
            Completa líneas horizontales para ganar puntos
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Game Board */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Tablero de Juego</span>
                  <div className="flex items-center gap-2">
                    {!isPlaying ? (
                      <Button onClick={startGame}>
                        <Play className="mr-2 h-4 w-4" />
                        Jugar
                      </Button>
                    ) : (
                      <>
                        <Button variant="outline" onClick={pauseGame}>
                          {isPaused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
                        </Button>
                        <Button variant="outline" onClick={resetGame}>
                          Reiniciar
                        </Button>
                      </>
                    )}
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="relative">
                  <div
                    className="grid bg-gray-900 border-2 border-gray-700 mx-auto"
                    style={{
                      gridTemplateColumns: `repeat(${BOARD_WIDTH}, 1fr)`,
                      width: '300px',
                      height: '600px'
                    }}
                  >
                    {displayBoard.flat().map((cell, index) => (
                      <div
                        key={index}
                        className="border border-gray-800"
                        style={{
                          backgroundColor: COLORS[cell],
                          width: '30px',
                          height: '30px'
                        }}
                      />
                    ))}
                  </div>
                  
                  {gameOver && (
                    <div className="absolute inset-0 bg-black/80 flex items-center justify-center">
                      <div className="text-center text-white">
                        <h3 className="text-2xl font-bold mb-4">¡Juego Terminado!</h3>
                        <p className="mb-4">Puntuación: {score}</p>
                        <Button onClick={startGame}>
                          <Play className="mr-2 h-4 w-4" />
                          Jugar de Nuevo
                        </Button>
                      </div>
                    </div>
                  )}
                  
                  {isPaused && !gameOver && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                      <div className="text-center text-white">
                        <Pause className="h-12 w-12 mx-auto mb-4" />
                        <h3 className="text-xl font-bold">Pausado</h3>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Game Info */}
          <div className="lg:col-span-2 space-y-6">
            {/* Stats */}
            <Card>
              <CardHeader>
                <CardTitle>Estadísticas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold">{score}</div>
                    <div className="text-sm text-muted-foreground">Puntuación</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{lines}</div>
                    <div className="text-sm text-muted-foreground">Líneas</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{level}</div>
                    <div className="text-sm text-muted-foreground">Nivel</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold">{Math.max(0, 10 - (lines % 10))}</div>
                    <div className="text-sm text-muted-foreground">Siguiente Nivel</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Next Piece */}
            {nextPiece && (
              <Card>
                <CardHeader>
                  <CardTitle>Siguiente Pieza</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-center">
                    <div
                      className="grid bg-gray-900 border border-gray-700"
                      style={{
                        gridTemplateColumns: `repeat(4, 1fr)`,
                        width: '120px',
                        height: '120px'
                      }}
                    >
                      {Array(16).fill(0).map((_, index) => {
                        const row = Math.floor(index / 4)
                        const col = index % 4
                        const cell = nextPiece.shape[row] && nextPiece.shape[row][col] 
                          ? nextPiece.color 
                          : 0
                        
                        return (
                          <div
                            key={index}
                            className="border border-gray-800"
                            style={{
                              backgroundColor: COLORS[cell],
                              width: '30px',
                              height: '30px'
                            }}
                          />
                        )
                      })}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Controls */}
            <Card>
              <CardHeader>
                <CardTitle>Controles</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Button 
                      variant="outline" 
                      onClick={() => movePiece('left')}
                      disabled={!isPlaying || isPaused || gameOver}
                    >
                      <ArrowLeft className="mr-2 h-4 w-4" />
                      Izquierda
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => movePiece('right')}
                      disabled={!isPlaying || isPaused || gameOver}
                    >
                      <ArrowRight className="mr-2 h-4 w-4" />
                      Derecha
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => movePiece('down')}
                      disabled={!isPlaying || isPaused || gameOver}
                    >
                      <ArrowDown className="mr-2 h-4 w-4" />
                      Bajar
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => movePiece('rotate')}
                      disabled={!isPlaying || isPaused || gameOver}
                    >
                      <RotateCw className="mr-2 h-4 w-4" />
                      Rotar
                    </Button>
                  </div>
                  
                  <div className="text-sm text-muted-foreground space-y-1">
                    <div className="flex items-center gap-2">
                      <kbd className="px-2 py-1 bg-muted rounded text-xs">←→</kbd>
                      <span>Mover izquierda/derecha</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <kbd className="px-2 py-1 bg-muted rounded text-xs">↓</kbd>
                      <span>Acelerar caída</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <kbd className="px-2 py-1 bg-muted rounded text-xs">↑</kbd>
                      <span>Rotar pieza</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <kbd className="px-2 py-1 bg-muted rounded text-xs">Space</kbd>
                      <span>Rotar pieza</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Back to Games */}
            <Card>
              <CardContent className="pt-6">
                <Button variant="outline" className="w-full" asChild>
                  <Link href="/games">
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Volver a Juegos
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </motion.div>
    </div>
  )
}
