

'use client'

import { useState, useEffect, useCallback } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { 
  Play, 
  RotateCcw, 
  Trophy, 
  Star, 
  Crown,
  Clock,
  Gamepad2,
  Brain
} from 'lucide-react'
import { motion } from 'framer-motion'

interface Card {
  id: number
  value: string
  isFlipped: boolean
  isMatched: boolean
}

interface GameState {
  cards: Card[]
  flippedCards: Card[]
  moves: number
  matchedPairs: number
  isGameComplete: boolean
  isPlaying: boolean
  startTime: Date | null
  endTime: Date | null
}

interface HighScore {
  id: string
  score: number
  userName: string
  playedAt: string
}

const CARD_EMOJIS = ['🎯', '🎪', '🎭', '🎨', '🎸', '🎺', '🎵', '🎲', '🎳', '🚀', '🌟', '⭐', '🍎', '🍊', '🍋', '🍌', '🍇', '🍓']

export function MemoryGame() {
  const { data: session } = useSession()
  
  const [gameState, setGameState] = useState<GameState>({
    cards: [],
    flippedCards: [],
    moves: 0,
    matchedPairs: 0,
    isGameComplete: false,
    isPlaying: false,
    startTime: null,
    endTime: null
  })
  
  const [highScores, setHighScores] = useState<HighScore[]>([])
  const [personalBest, setPersonalBest] = useState(0)
  const [difficulty, setDifficulty] = useState<'easy' | 'medium' | 'hard'>('easy')

  const getDifficultyConfig = (diff: 'easy' | 'medium' | 'hard') => {
    switch (diff) {
      case 'easy': return { pairs: 6, gridCols: 4, gridRows: 3 }
      case 'medium': return { pairs: 8, gridCols: 4, gridRows: 4 }
      case 'hard': return { pairs: 12, gridCols: 6, gridRows: 4 }
    }
  }

  // Initialize cards
  const initializeCards = useCallback((diff: 'easy' | 'medium' | 'hard') => {
    const config = getDifficultyConfig(diff)
    const selectedEmojis = CARD_EMOJIS.slice(0, config.pairs)
    const cardPairs = [...selectedEmojis, ...selectedEmojis]
    
    // Shuffle cards
    const shuffledCards = cardPairs
      .map((value, index) => ({
        id: index,
        value,
        isFlipped: false,
        isMatched: false
      }))
      .sort(() => Math.random() - 0.5)

    return shuffledCards
  }, [])

  // Start game
  const startGame = (selectedDifficulty: 'easy' | 'medium' | 'hard' = difficulty) => {
    const cards = initializeCards(selectedDifficulty)
    setGameState({
      cards,
      flippedCards: [],
      moves: 0,
      matchedPairs: 0,
      isGameComplete: false,
      isPlaying: true,
      startTime: new Date(),
      endTime: null
    })
    setDifficulty(selectedDifficulty)
  }

  // Handle card click
  const handleCardClick = (clickedCard: Card) => {
    if (
      !gameState.isPlaying ||
      gameState.isGameComplete ||
      clickedCard.isFlipped ||
      clickedCard.isMatched ||
      gameState.flippedCards.length >= 2
    ) {
      return
    }

    const updatedCards = gameState.cards.map(card =>
      card.id === clickedCard.id ? { ...card, isFlipped: true } : card
    )

    const newFlippedCards = [...gameState.flippedCards, { ...clickedCard, isFlipped: true }]

    setGameState(prev => ({
      ...prev,
      cards: updatedCards,
      flippedCards: newFlippedCards,
      moves: prev.moves + 1
    }))

    // Check for match if 2 cards are flipped
    if (newFlippedCards.length === 2) {
      setTimeout(() => {
        checkForMatch(newFlippedCards, updatedCards)
      }, 1000)
    }
  }

  // Check if two flipped cards match
  const checkForMatch = (flippedCards: Card[], currentCards: Card[]) => {
    const [card1, card2] = flippedCards

    if (card1.value === card2.value) {
      // Match found
      const updatedCards = currentCards.map(card => {
        if (card.id === card1.id || card.id === card2.id) {
          return { ...card, isMatched: true }
        }
        return { ...card, isFlipped: false }
      })

      const newMatchedPairs = gameState.matchedPairs + 1
      const config = getDifficultyConfig(difficulty)
      const isComplete = newMatchedPairs === config.pairs

      setGameState(prev => ({
        ...prev,
        cards: updatedCards,
        flippedCards: [],
        matchedPairs: newMatchedPairs,
        isGameComplete: isComplete,
        endTime: isComplete ? new Date() : null
      }))

      if (isComplete) {
        saveHighScore()
      }
    } else {
      // No match - flip cards back
      const updatedCards = currentCards.map(card => {
        if (card.id === card1.id || card.id === card2.id) {
          return { ...card, isFlipped: false }
        }
        return card
      })

      setGameState(prev => ({
        ...prev,
        cards: updatedCards,
        flippedCards: []
      }))
    }
  }

  // Calculate score based on moves and time
  const calculateScore = () => {
    if (!gameState.startTime || !gameState.endTime) return 0
    
    const timeBonus = Math.max(0, 300 - Math.floor((gameState.endTime.getTime() - gameState.startTime.getTime()) / 1000))
    const moveBonus = Math.max(0, 100 - gameState.moves)
    const difficultyMultiplier = difficulty === 'easy' ? 1 : difficulty === 'medium' ? 1.5 : 2
    
    return Math.floor((timeBonus + moveBonus) * difficultyMultiplier)
  }

  // Save high score
  const saveHighScore = async () => {
    if (!session?.user || !gameState.startTime || !gameState.endTime) return

    const score = calculateScore()
    const duration = Math.floor((gameState.endTime.getTime() - gameState.startTime.getTime()) / 1000)

    try {
      const response = await fetch('/api/games/save-score', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          gameType: 'memory',
          score,
          level: difficulty === 'easy' ? 1 : difficulty === 'medium' ? 2 : 3,
          duration
        }),
      })

      if (response.ok) {
        fetchHighScores()
      }
    } catch (error) {
      console.error('Error saving high score:', error)
    }
  }

  // Fetch high scores
  const fetchHighScores = async () => {
    try {
      const response = await fetch('/api/games/high-scores?gameType=memory')
      if (response.ok) {
        const data = await response.json()
        setHighScores(data.scores || [])
        setPersonalBest(data.personalBest || 0)
      }
    } catch (error) {
      console.error('Error fetching high scores:', error)
    }
  }

  // Reset game
  const resetGame = () => {
    setGameState({
      cards: [],
      flippedCards: [],
      moves: 0,
      matchedPairs: 0,
      isGameComplete: false,
      isPlaying: false,
      startTime: null,
      endTime: null
    })
  }

  // Get game time
  const getGameTime = () => {
    if (!gameState.startTime) return 0
    const endTime = gameState.endTime || new Date()
    return Math.floor((endTime.getTime() - gameState.startTime.getTime()) / 1000)
  }

  useEffect(() => {
    fetchHighScores()
  }, [])

  const config = getDifficultyConfig(difficulty)

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-2xl bg-pink-500 flex items-center justify-center">
              <Brain className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            🧠 Memory Game
          </h1>
          <p className="text-lg text-muted-foreground">
            Encuentra todas las parejas de cartas con la menor cantidad de movimientos
          </p>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
          {/* Game Area */}
          <div className="xl:col-span-3">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Gamepad2 className="h-5 w-5" />
                    Área de Juego
                  </CardTitle>
                  <div className="flex items-center gap-4">
                    <Badge variant="outline">
                      <Star className="mr-1 h-3 w-3" />
                      {gameState.moves} movimientos
                    </Badge>
                    <Badge variant="outline">
                      <Clock className="mr-1 h-3 w-3" />
                      {getGameTime()}s
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Game Controls */}
                  <div className="flex items-center gap-2 flex-wrap">
                    {!gameState.isPlaying && (
                      <>
                        <Button onClick={() => startGame('easy')} variant={difficulty === 'easy' ? 'default' : 'outline'}>
                          <Play className="mr-2 h-4 w-4" />
                          Fácil (6 pares)
                        </Button>
                        <Button onClick={() => startGame('medium')} variant={difficulty === 'medium' ? 'default' : 'outline'}>
                          <Play className="mr-2 h-4 w-4" />
                          Medio (8 pares)
                        </Button>
                        <Button onClick={() => startGame('hard')} variant={difficulty === 'hard' ? 'default' : 'outline'}>
                          <Play className="mr-2 h-4 w-4" />
                          Difícil (12 pares)
                        </Button>
                      </>
                    )}
                    
                    <Button onClick={resetGame} variant="outline">
                      <RotateCcw className="mr-2 h-4 w-4" />
                      Reiniciar
                    </Button>
                  </div>

                  {/* Game Board */}
                  {gameState.isPlaying && (
                    <div 
                      className={`grid gap-2 mx-auto`}
                      style={{
                        gridTemplateColumns: `repeat(${config.gridCols}, 1fr)`,
                        maxWidth: `${config.gridCols * 80 + (config.gridCols - 1) * 8}px`
                      }}
                    >
                      {gameState.cards.map((card, index) => (
                        <motion.div
                          key={card.id}
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ delay: index * 0.05 }}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          <div
                            className={`
                              aspect-square w-20 h-20 rounded-lg border-2 cursor-pointer
                              flex items-center justify-center text-2xl font-bold
                              transition-all duration-300 select-none
                              ${card.isFlipped || card.isMatched
                                ? 'bg-white dark:bg-gray-800 border-blue-500 shadow-lg' 
                                : 'bg-gradient-to-br from-blue-500 to-purple-600 border-blue-400 hover:from-blue-600 hover:to-purple-700'
                              }
                              ${card.isMatched ? 'opacity-60' : ''}
                            `}
                            onClick={() => handleCardClick(card)}
                          >
                            {card.isFlipped || card.isMatched ? card.value : '?'}
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  )}

                  {/* Game Complete */}
                  {gameState.isGameComplete && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="text-center p-6 bg-gradient-to-r from-green-100 to-blue-100 dark:from-green-900 dark:to-blue-900 rounded-lg"
                    >
                      <Trophy className="h-12 w-12 mx-auto mb-4 text-yellow-500" />
                      <h3 className="text-2xl font-bold mb-2">¡Felicitaciones!</h3>
                      <p className="text-lg mb-2">Completaste el juego en {gameState.moves} movimientos</p>
                      <p className="text-md mb-4">Tiempo: {getGameTime()} segundos</p>
                      <p className="text-lg font-semibold text-green-600 dark:text-green-400">
                        Puntuación: {calculateScore()} puntos
                      </p>
                    </motion.div>
                  )}

                  {/* Game Info */}
                  {gameState.isPlaying && (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                      <div className="p-3 bg-muted rounded-lg">
                        <div className="text-2xl font-bold text-blue-500">{gameState.moves}</div>
                        <div className="text-sm text-muted-foreground">Movimientos</div>
                      </div>
                      <div className="p-3 bg-muted rounded-lg">
                        <div className="text-2xl font-bold text-green-500">{gameState.matchedPairs}</div>
                        <div className="text-sm text-muted-foreground">Parejas</div>
                      </div>
                      <div className="p-3 bg-muted rounded-lg">
                        <div className="text-2xl font-bold text-purple-500">{getGameTime()}</div>
                        <div className="text-sm text-muted-foreground">Segundos</div>
                      </div>
                      <div className="p-3 bg-muted rounded-lg">
                        <div className="text-2xl font-bold text-pink-500">
                          {difficulty === 'easy' ? 'Fácil' : difficulty === 'medium' ? 'Medio' : 'Difícil'}
                        </div>
                        <div className="text-sm text-muted-foreground">Dificultad</div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Personal Best */}
            {personalBest > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Crown className="h-5 w-5 text-yellow-500" />
                    Tu Mejor Puntuación
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-yellow-500">{personalBest}</div>
                    <div className="text-sm text-muted-foreground">Puntos</div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* High Scores */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="h-5 w-5" />
                  Ranking Global
                </CardTitle>
                <CardDescription>
                  Top 10 mejores puntuaciones
                </CardDescription>
              </CardHeader>
              <CardContent>
                {highScores.length === 0 ? (
                  <div className="text-center py-4 text-muted-foreground">
                    No hay puntuaciones aún
                  </div>
                ) : (
                  <div className="space-y-2">
                    {highScores.slice(0, 10).map((score, index) => (
                      <div key={score.id} className="flex items-center justify-between p-2 bg-muted rounded">
                        <div className="flex items-center gap-2">
                          <Badge variant={index < 3 ? 'default' : 'outline'} className="w-6 h-6 p-0 flex items-center justify-center text-xs">
                            {index + 1}
                          </Badge>
                          <span className="font-medium text-sm truncate max-w-[100px]">
                            {score.userName}
                          </span>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold text-sm">{score.score}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Game Tips */}
            <Card>
              <CardHeader>
                <CardTitle>Consejos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <p>🧠 Memoriza las posiciones de las cartas</p>
                  <p>⏰ Menos tiempo = más puntos</p>
                  <p>🎯 Menos movimientos = más puntos</p>
                  <p>📈 Mayor dificultad = más puntos</p>
                  <p>🏆 ¡Practica para mejorar tu memoria!</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </motion.div>
    </div>
  )
}
