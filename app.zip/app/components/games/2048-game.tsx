

'use client'

import { useState, useEffect, useCallback } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { 
  Play, 
  RotateCcw, 
  Trophy, 
  Star, 
  Crown,
  ArrowUp,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  Gamepad2,
  Grid3x3
} from 'lucide-react'
import { motion } from 'framer-motion'

type Grid = number[][]

interface GameState {
  grid: Grid
  score: number
  bestScore: number
  isGameOver: boolean
  isWon: boolean
  isPlaying: boolean
  canUndo: boolean
}

interface HighScore {
  id: string
  score: number
  userName: string
  playedAt: string
}

const GRID_SIZE = 4

export function Game2048() {
  const { data: session } = useSession()
  
  const [gameState, setGameState] = useState<GameState>({
    grid: Array(GRID_SIZE).fill(null).map(() => Array(GRID_SIZE).fill(0)),
    score: 0,
    bestScore: 0,
    isGameOver: false,
    isWon: false,
    isPlaying: false,
    canUndo: false
  })
  
  const [previousState, setPreviousState] = useState<GameState | null>(null)
  const [highScores, setHighScores] = useState<HighScore[]>([])
  const [personalBest, setPersonalBest] = useState(0)

  // Initialize empty grid
  const createEmptyGrid = (): Grid => {
    return Array(GRID_SIZE).fill(null).map(() => Array(GRID_SIZE).fill(0))
  }

  // Get empty cells
  const getEmptyCells = (grid: Grid): [number, number][] => {
    const emptyCells: [number, number][] = []
    for (let row = 0; row < GRID_SIZE; row++) {
      for (let col = 0; col < GRID_SIZE; col++) {
        if (grid[row][col] === 0) {
          emptyCells.push([row, col])
        }
      }
    }
    return emptyCells
  }

  // Add random tile (2 or 4)
  const addRandomTile = (grid: Grid): Grid => {
    const emptyCells = getEmptyCells(grid)
    if (emptyCells.length === 0) return grid

    const newGrid = grid.map(row => [...row])
    const randomCell = emptyCells[Math.floor(Math.random() * emptyCells.length)]
    const value = Math.random() < 0.9 ? 2 : 4
    
    newGrid[randomCell[0]][randomCell[1]] = value
    return newGrid
  }

  // Start new game
  const startNewGame = () => {
    let newGrid = createEmptyGrid()
    newGrid = addRandomTile(newGrid)
    newGrid = addRandomTile(newGrid)
    
    setGameState({
      grid: newGrid,
      score: 0,
      bestScore: Math.max(gameState.bestScore, personalBest),
      isGameOver: false,
      isWon: false,
      isPlaying: true,
      canUndo: false
    })
    setPreviousState(null)
  }

  // Move tiles
  const moveTiles = (direction: 'up' | 'down' | 'left' | 'right') => {
    if (gameState.isGameOver || !gameState.isPlaying) return

    // Save current state for undo
    setPreviousState({ ...gameState })

    let newGrid = gameState.grid.map(row => [...row])
    let scoreIncrease = 0
    let moved = false

    const moveAndMergeRow = (row: number[]): { row: number[], score: number, moved: boolean } => {
      const filteredRow = row.filter(cell => cell !== 0)
      const newRow = [...filteredRow]
      let rowScore = 0
      let rowMoved = filteredRow.length !== row.filter(cell => cell !== 0).length

      // Merge tiles
      for (let i = 0; i < newRow.length - 1; i++) {
        if (newRow[i] === newRow[i + 1]) {
          newRow[i] *= 2
          rowScore += newRow[i]
          newRow.splice(i + 1, 1)
          rowMoved = true
        }
      }

      // Fill with zeros
      while (newRow.length < GRID_SIZE) {
        newRow.push(0)
      }

      // Check if row actually moved
      if (!rowMoved) {
        rowMoved = !row.every((cell, index) => cell === newRow[index])
      }

      return { row: newRow, score: rowScore, moved: rowMoved }
    }

    if (direction === 'left') {
      for (let row = 0; row < GRID_SIZE; row++) {
        const result = moveAndMergeRow(newGrid[row])
        newGrid[row] = result.row
        scoreIncrease += result.score
        if (result.moved) moved = true
      }
    } else if (direction === 'right') {
      for (let row = 0; row < GRID_SIZE; row++) {
        const reversedRow = [...newGrid[row]].reverse()
        const result = moveAndMergeRow(reversedRow)
        newGrid[row] = result.row.reverse()
        scoreIncrease += result.score
        if (result.moved) moved = true
      }
    } else if (direction === 'up') {
      for (let col = 0; col < GRID_SIZE; col++) {
        const column = newGrid.map(row => row[col])
        const result = moveAndMergeRow(column)
        for (let row = 0; row < GRID_SIZE; row++) {
          newGrid[row][col] = result.row[row]
        }
        scoreIncrease += result.score
        if (result.moved) moved = true
      }
    } else if (direction === 'down') {
      for (let col = 0; col < GRID_SIZE; col++) {
        const column = newGrid.map(row => row[col]).reverse()
        const result = moveAndMergeRow(column)
        const reversedResult = result.row.reverse()
        for (let row = 0; row < GRID_SIZE; row++) {
          newGrid[row][col] = reversedResult[row]
        }
        scoreIncrease += result.score
        if (result.moved) moved = true
      }
    }

    if (moved) {
      newGrid = addRandomTile(newGrid)
      const newScore = gameState.score + scoreIncrease
      const isWon = newGrid.some(row => row.some(cell => cell >= 2048)) && !gameState.isWon
      const isGameOver = checkGameOver(newGrid)

      setGameState(prev => ({
        ...prev,
        grid: newGrid,
        score: newScore,
        bestScore: Math.max(prev.bestScore, newScore),
        isWon: isWon,
        isGameOver: isGameOver,
        canUndo: true
      }))

      if (isGameOver || isWon) {
        saveHighScore(newScore)
      }
    }
  }

  // Check if game is over
  const checkGameOver = (grid: Grid): boolean => {
    // Check for empty cells
    if (getEmptyCells(grid).length > 0) return false

    // Check for possible merges
    for (let row = 0; row < GRID_SIZE; row++) {
      for (let col = 0; col < GRID_SIZE; col++) {
        const current = grid[row][col]
        // Check right
        if (col < GRID_SIZE - 1 && current === grid[row][col + 1]) return false
        // Check down
        if (row < GRID_SIZE - 1 && current === grid[row + 1][col]) return false
      }
    }

    return true
  }

  // Undo last move
  const undoMove = () => {
    if (previousState && gameState.canUndo) {
      setGameState({ ...previousState, canUndo: false })
      setPreviousState(null)
    }
  }

  // Handle keyboard input
  const handleKeyPress = useCallback((event: KeyboardEvent) => {
    if (!gameState.isPlaying) return

    switch (event.key) {
      case 'ArrowUp':
        event.preventDefault()
        moveTiles('up')
        break
      case 'ArrowDown':
        event.preventDefault()
        moveTiles('down')
        break
      case 'ArrowLeft':
        event.preventDefault()
        moveTiles('left')
        break
      case 'ArrowRight':
        event.preventDefault()
        moveTiles('right')
        break
    }
  }, [gameState.isPlaying])

  // Save high score
  const saveHighScore = async (finalScore: number) => {
    if (!session?.user) return

    try {
      const response = await fetch('/api/games/save-score', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          gameType: '2048',
          score: finalScore,
          level: 1
        }),
      })

      if (response.ok) {
        fetchHighScores()
      }
    } catch (error) {
      console.error('Error saving high score:', error)
    }
  }

  // Fetch high scores
  const fetchHighScores = async () => {
    try {
      const response = await fetch('/api/games/high-scores?gameType=2048')
      if (response.ok) {
        const data = await response.json()
        setHighScores(data.scores || [])
        setPersonalBest(data.personalBest || 0)
      }
    } catch (error) {
      console.error('Error fetching high scores:', error)
    }
  }

  // Get tile color
  const getTileColor = (value: number): string => {
    const colors: { [key: number]: string } = {
      0: 'bg-gray-200 dark:bg-gray-700',
      2: 'bg-gray-100 dark:bg-gray-600 text-gray-700 dark:text-gray-300',
      4: 'bg-gray-200 dark:bg-gray-500 text-gray-700 dark:text-gray-200',
      8: 'bg-orange-300 text-white',
      16: 'bg-orange-400 text-white',
      32: 'bg-orange-500 text-white',
      64: 'bg-red-400 text-white',
      128: 'bg-yellow-300 text-white',
      256: 'bg-yellow-400 text-white',
      512: 'bg-yellow-500 text-white',
      1024: 'bg-green-400 text-white',
      2048: 'bg-green-500 text-white',
      4096: 'bg-blue-400 text-white',
      8192: 'bg-blue-500 text-white'
    }
    return colors[value] || 'bg-purple-500 text-white'
  }

  // Get tile font size
  const getTileFontSize = (value: number): string => {
    if (value >= 1000) return 'text-lg'
    if (value >= 100) return 'text-xl'
    return 'text-2xl'
  }

  useEffect(() => {
    document.addEventListener('keydown', handleKeyPress)
    return () => {
      document.removeEventListener('keydown', handleKeyPress)
    }
  }, [handleKeyPress])

  useEffect(() => {
    fetchHighScores()
  }, [])

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-2xl bg-orange-500 flex items-center justify-center">
              <Grid3x3 className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            🎯 2048 Game
          </h1>
          <p className="text-lg text-muted-foreground">
            Combina los números para llegar a 2048. ¡Un desafío adictivo para tu mente!
          </p>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
          {/* Game Area */}
          <div className="xl:col-span-3">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Gamepad2 className="h-5 w-5" />
                    Área de Juego
                  </CardTitle>
                  <div className="flex items-center gap-4">
                    <Badge variant="outline">
                      <Star className="mr-1 h-3 w-3" />
                      {gameState.score}
                    </Badge>
                    <Badge variant="outline">
                      <Crown className="mr-1 h-3 w-3" />
                      Mejor: {Math.max(gameState.bestScore, personalBest)}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Game Controls */}
                  <div className="flex items-center gap-2">
                    <Button onClick={startNewGame}>
                      <Play className="mr-2 h-4 w-4" />
                      {gameState.isPlaying ? 'Nuevo Juego' : 'Iniciar Juego'}
                    </Button>
                    
                    {gameState.canUndo && (
                      <Button onClick={undoMove} variant="outline">
                        <RotateCcw className="mr-2 h-4 w-4" />
                        Deshacer
                      </Button>
                    )}
                  </div>

                  {/* Game Board */}
                  <div className="flex justify-center">
                    <div 
                      className="inline-block p-4 bg-gray-300 dark:bg-gray-700 rounded-lg"
                      style={{ width: 'fit-content' }}
                    >
                      <div className="grid grid-cols-4 gap-2">
                        {gameState.grid.flat().map((value, index) => (
                          <motion.div
                            key={index}
                            initial={{ scale: value > 0 ? 0 : 1 }}
                            animate={{ scale: 1 }}
                            transition={{ duration: 0.15 }}
                            className={`
                              w-16 h-16 rounded-md flex items-center justify-center font-bold
                              ${getTileColor(value)} ${getTileFontSize(value)}
                              transition-all duration-150
                            `}
                          >
                            {value > 0 ? value : ''}
                          </motion.div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Game Status */}
                  {gameState.isWon && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="text-center p-6 bg-gradient-to-r from-green-100 to-yellow-100 dark:from-green-900 dark:to-yellow-900 rounded-lg"
                    >
                      <Trophy className="h-12 w-12 mx-auto mb-4 text-yellow-500" />
                      <h3 className="text-2xl font-bold mb-2">¡Felicitaciones!</h3>
                      <p className="text-lg mb-2">¡Llegaste a 2048!</p>
                      <p className="text-md">Puntuación: {gameState.score}</p>
                    </motion.div>
                  )}

                  {gameState.isGameOver && !gameState.isWon && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="text-center p-6 bg-gradient-to-r from-red-100 to-pink-100 dark:from-red-900 dark:to-pink-900 rounded-lg"
                    >
                      <h3 className="text-2xl font-bold mb-2">¡Juego Terminado!</h3>
                      <p className="text-lg mb-2">Puntuación Final: {gameState.score}</p>
                      <Button onClick={startNewGame} className="mt-4">
                        <Play className="mr-2 h-4 w-4" />
                        Jugar de Nuevo
                      </Button>
                    </motion.div>
                  )}

                  {/* Game Info */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                    <div className="p-3 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-orange-500">{gameState.score}</div>
                      <div className="text-sm text-muted-foreground">Puntuación</div>
                    </div>
                    <div className="p-3 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-yellow-500">{Math.max(gameState.bestScore, personalBest)}</div>
                      <div className="text-sm text-muted-foreground">Mejor</div>
                    </div>
                    <div className="p-3 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-green-500">
                        {Math.max(...gameState.grid.flat())}
                      </div>
                      <div className="text-sm text-muted-foreground">Mayor Tile</div>
                    </div>
                    <div className="p-3 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-blue-500">
                        {getEmptyCells(gameState.grid).length}
                      </div>
                      <div className="text-sm text-muted-foreground">Espacios</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Controls */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Gamepad2 className="h-5 w-5" />
                  Controles
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="text-center">
                    <Button variant="outline" size="sm" className="p-2">
                      <ArrowUp className="h-4 w-4" />
                    </Button>
                    <div className="text-xs mt-1">↑ Arriba</div>
                  </div>
                  <div className="flex justify-center gap-2">
                    <div className="text-center">
                      <Button variant="outline" size="sm" className="p-2">
                        <ArrowLeft className="h-4 w-4" />
                      </Button>
                      <div className="text-xs mt-1">← Izq</div>
                    </div>
                    <div className="text-center">
                      <Button variant="outline" size="sm" className="p-2">
                        <ArrowDown className="h-4 w-4" />
                      </Button>
                      <div className="text-xs mt-1">↓ Abajo</div>
                    </div>
                    <div className="text-center">
                      <Button variant="outline" size="sm" className="p-2">
                        <ArrowRight className="h-4 w-4" />
                      </Button>
                      <div className="text-xs mt-1">→ Der</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Personal Best */}
            {personalBest > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Crown className="h-5 w-5 text-yellow-500" />
                    Tu Mejor Puntuación
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-yellow-500">{personalBest}</div>
                    <div className="text-sm text-muted-foreground">Puntos</div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* High Scores */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="h-5 w-5" />
                  Ranking Global
                </CardTitle>
                <CardDescription>
                  Top 10 mejores puntuaciones
                </CardDescription>
              </CardHeader>
              <CardContent>
                {highScores.length === 0 ? (
                  <div className="text-center py-4 text-muted-foreground">
                    No hay puntuaciones aún
                  </div>
                ) : (
                  <div className="space-y-2">
                    {highScores.slice(0, 10).map((score, index) => (
                      <div key={score.id} className="flex items-center justify-between p-2 bg-muted rounded">
                        <div className="flex items-center gap-2">
                          <Badge variant={index < 3 ? 'default' : 'outline'} className="w-6 h-6 p-0 flex items-center justify-center text-xs">
                            {index + 1}
                          </Badge>
                          <span className="font-medium text-sm truncate max-w-[100px]">
                            {score.userName}
                          </span>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold text-sm">{score.score}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Game Tips */}
            <Card>
              <CardHeader>
                <CardTitle>Consejos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm text-muted-foreground">
                  <p>🎯 Mantén los números altos en una esquina</p>
                  <p>📊 Construye secuencias ordenadas</p>
                  <p>🚫 No muevas aleatoriamente</p>
                  <p>🧠 Planifica varios movimientos adelante</p>
                  <p>🔄 Usa la función deshacer sabiamente</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </motion.div>
    </div>
  )
}
