
'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Trophy, 
  Target, 
  Code2, 
  Play, 
  CheckCircle, 
  XCircle, 
  Clock,
  Star,
  ArrowLeft,
  Lightbulb,
  TestTube,
  History,
  Award
} from 'lucide-react'
import { motion } from 'framer-motion'
import Link from 'next/link'

interface Exercise {
  id: string
  title: string
  description: string
  language: string
  difficulty: string
  points: number
  category: string
  testCases: any[]
  starterCode?: string
}

interface Submission {
  id: string
  status: string
  score: number
  submittedAt: string
  executionTime?: number
}

interface SubmissionResult {
  id: string
  status: string
  score: number
  passed: boolean
  testResults: any[]
  feedback: string
  pointsEarned: number
}

interface ExerciseSolverProps {
  exerciseId: string
}

export function ExerciseSolver({ exerciseId }: ExerciseSolverProps) {
  const { data: session } = useSession()
  const [exercise, setExercise] = useState<Exercise | null>(null)
  const [code, setCode] = useState('')
  const [submissions, setSubmissions] = useState<Submission[]>([])
  const [bestScore, setBestScore] = useState(0)
  const [isCompleted, setIsCompleted] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submissionResult, setSubmissionResult] = useState<SubmissionResult | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    fetchExerciseData()
  }, [exerciseId])

  const fetchExerciseData = async () => {
    try {
      setIsLoading(true)
      const response = await fetch(`/api/practice/exercise/${exerciseId}`)
      
      if (response.ok) {
        const data = await response.json()
        setExercise(data.exercise)
        setSubmissions(data.userSubmissions || [])
        setBestScore(data.bestScore || 0)
        setIsCompleted(data.isCompleted || false)
        setCode(data.exercise.starterCode || '')
      } else {
        setError('Error al cargar el ejercicio')
      }
    } catch (err) {
      setError('Error al cargar el ejercicio')
      console.error('Error fetching exercise:', err)
    } finally {
      setIsLoading(false)
    }
  }

  const submitSolution = async () => {
    if (!code.trim() || !exercise) return

    setIsSubmitting(true)
    setSubmissionResult(null)
    setError('')

    try {
      const response = await fetch('/api/practice/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          exerciseId: exercise.id,
          code,
          language: exercise.language
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setSubmissionResult(data.submission)
        
        // Refresh exercise data to update completion status
        await fetchExerciseData()
      } else {
        const errorData = await response.json()
        setError(errorData.error || 'Error al evaluar la solución')
      }
    } catch (err) {
      setError('Error al enviar la solución')
      console.error('Submit error:', err)
    } finally {
      setIsSubmitting(false)
    }
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'bg-green-500'
      case 'intermediate': return 'bg-yellow-500'
      case 'advanced': return 'bg-red-500'
      default: return 'bg-gray-500'
    }
  }

  const getDifficultyLabel = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return '🟢 Principiante'
      case 'intermediate': return '🟡 Intermedio'
      case 'advanced': return '🔴 Avanzado'
      default: return difficulty
    }
  }

  const getLanguageIcon = (language: string) => {
    switch (language) {
      case 'python': return '🐍'
      case 'csharp': return '⚡'
      case 'cpp': return '🔥'
      default: return '💻'
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'basic-syntax': return '📚'
      case 'algorithms': return '🧠'
      case 'data-structures': return '🏗️'
      case 'math': return '🔢'
      case 'strings': return '🔤'
      default: return '📝'
    }
  }

  const resetCode = () => {
    setCode(exercise?.starterCode || '')
    setSubmissionResult(null)
    setError('')
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!exercise) {
    return (
      <div className="text-center py-12">
        <XCircle className="h-12 w-12 mx-auto mb-4 text-red-500" />
        <h3 className="text-lg font-semibold mb-2">Ejercicio no encontrado</h3>
        <p className="text-muted-foreground mb-4">
          El ejercicio que buscas no existe o no está disponible.
        </p>
        <Button asChild>
          <Link href="/practice">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Volver a Práctica
          </Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Back Button */}
        <div className="mb-6">
          <Button variant="outline" asChild>
            <Link href="/practice">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Volver a Práctica
            </Link>
          </Button>
        </div>

        {/* Exercise Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.6 }}
          className="mb-8"
        >
          <Card>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-3">
                    {isCompleted && <CheckCircle className="h-6 w-6 text-green-500" />}
                    <Badge variant="outline" className="text-sm">
                      {getLanguageIcon(exercise.language)} {exercise.language.toUpperCase()}
                    </Badge>
                    <Badge className={`${getDifficultyColor(exercise.difficulty)} text-white text-sm`}>
                      {getDifficultyLabel(exercise.difficulty)}
                    </Badge>
                    <Badge variant="secondary" className="text-sm">
                      {getCategoryIcon(exercise.category)} {exercise.category}
                    </Badge>
                  </div>
                  <CardTitle className="text-2xl mb-2">{exercise.title}</CardTitle>
                  <CardDescription className="text-base">
                    {exercise.description}
                  </CardDescription>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-2 mb-2">
                    <Star className="h-5 w-5 text-yellow-500" />
                    <span className="text-xl font-bold">{exercise.points}</span>
                  </div>
                  {bestScore > 0 && (
                    <Badge variant="outline" className="text-sm">
                      <Trophy className="mr-1 h-3 w-3" />
                      Mejor: {bestScore}%
                    </Badge>
                  )}
                </div>
              </div>
            </CardHeader>
          </Card>
        </motion.div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="xl:col-span-2 space-y-6">
            {/* Code Editor */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.6 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Code2 className="h-5 w-5" />
                    Solución
                  </CardTitle>
                  <CardDescription>
                    Escribe tu código {exercise.language.toUpperCase()} aquí
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Textarea
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    placeholder={`Escribe tu solución en ${exercise.language}...`}
                    className="min-h-[300px] font-mono text-sm resize-none"
                    style={{ 
                      fontSize: '14px',
                      lineHeight: '1.5',
                      fontFamily: '"Fira Code", "Consolas", "Monaco", monospace'
                    }}
                  />
                  
                  <div className="flex gap-2">
                    <Button 
                      onClick={submitSolution} 
                      disabled={isSubmitting || !code.trim()}
                      className="flex-1"
                    >
                      {isSubmitting ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                          Evaluando...
                        </>
                      ) : (
                        <>
                          <Play className="mr-2 h-4 w-4" />
                          Enviar Solución
                        </>
                      )}
                    </Button>
                    <Button onClick={resetCode} variant="outline">
                      Reiniciar
                    </Button>
                  </div>

                  {error && (
                    <Alert variant="destructive">
                      <XCircle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            {/* Submission Result */}
            {submissionResult && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4 }}
              >
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      {submissionResult.passed ? (
                        <CheckCircle className="h-5 w-5 text-green-500" />
                      ) : (
                        <XCircle className="h-5 w-5 text-red-500" />
                      )}
                      Resultado de Evaluación
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center gap-4">
                      <Badge variant={submissionResult.passed ? 'default' : 'destructive'}>
                        {submissionResult.passed ? 'Aprobado' : 'Fallido'}
                      </Badge>
                      <Badge variant="outline">
                        Puntuación: {submissionResult.score}%
                      </Badge>
                      {submissionResult.pointsEarned > 0 && (
                        <Badge className="bg-yellow-500 text-white">
                          <Award className="mr-1 h-3 w-3" />
                          +{submissionResult.pointsEarned} puntos
                        </Badge>
                      )}
                    </div>

                    {submissionResult.testResults && submissionResult.testResults.length > 0 && (
                      <div className="space-y-2">
                        <h4 className="font-semibold">Casos de Prueba:</h4>
                        {submissionResult.testResults.map((result: any, index: number) => (
                          <div key={index} className="p-3 bg-muted rounded-lg">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-medium">Caso {result.case}:</span>
                              {result.passed ? (
                                <CheckCircle className="h-4 w-4 text-green-500" />
                              ) : (
                                <XCircle className="h-4 w-4 text-red-500" />
                              )}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              <div>Esperado: <code>{result.expected}</code></div>
                              <div>Obtenido: <code>{result.output}</code></div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {submissionResult.feedback && (
                      <div className="p-3 bg-muted rounded-lg">
                        <h4 className="font-semibold mb-2 flex items-center gap-2">
                          <Lightbulb className="h-4 w-4" />
                          Feedback
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          {submissionResult.feedback}
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Test Cases */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TestTube className="h-5 w-5" />
                    Casos de Prueba
                  </CardTitle>
                  <CardDescription>
                    Ejemplos de entrada y salida esperada
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {exercise.testCases.map((testCase: any, index: number) => (
                      <div key={index} className="p-3 bg-muted rounded-lg">
                        <div className="font-medium mb-2">Caso {index + 1}:</div>
                        <div className="text-sm space-y-1">
                          {testCase.input && (
                            <div>
                              <span className="text-muted-foreground">Entrada:</span>
                              <code className="ml-2 bg-background px-1 rounded">
                                {testCase.input}
                              </code>
                            </div>
                          )}
                          <div>
                            <span className="text-muted-foreground">Salida esperada:</span>
                            <code className="ml-2 bg-background px-1 rounded">
                              {testCase.expected}
                            </code>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Submission History */}
            {submissions.length > 0 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4, duration: 0.6 }}
              >
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <History className="h-5 w-5" />
                      Historial
                    </CardTitle>
                    <CardDescription>
                      Tus intentos anteriores
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {submissions.slice(0, 5).map((submission) => (
                        <div key={submission.id} className="p-3 bg-muted rounded-lg">
                          <div className="flex items-center justify-between mb-1">
                            <Badge variant={submission.status === 'passed' ? 'default' : 'destructive'} className="text-xs">
                              {submission.status === 'passed' ? 'Aprobado' : 
                               submission.status === 'failed' ? 'Fallido' : 'Error'}
                            </Badge>
                            <span className="text-xs text-muted-foreground">
                              {submission.score}%
                            </span>
                          </div>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <Clock className="h-3 w-3" />
                            {new Date(submission.submittedAt).toLocaleString()}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* Exercise Stats */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5, duration: 0.6 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle>Estadísticas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Puntos:</span>
                      <span className="font-semibold">{exercise.points}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Intentos:</span>
                      <span className="font-semibold">{submissions.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Mejor puntuación:</span>
                      <span className="font-semibold">{bestScore}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Estado:</span>
                      <Badge variant={isCompleted ? 'default' : 'secondary'} className="text-xs">
                        {isCompleted ? 'Completado' : 'Pendiente'}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </motion.div>
    </div>
  )
}
