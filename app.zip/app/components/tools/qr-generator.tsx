

'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { QrCode } from 'lucide-react'
import { motion } from 'framer-motion'

export function QRGenerator() {
  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-2xl bg-slate-500 flex items-center justify-center">
              <QrCode className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            📱 Generador de Códigos QR
          </h1>
          <p className="text-lg text-muted-foreground">
            Genera códigos QR para texto, URLs, contactos y más
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>En Desarrollo</CardTitle>
            <CardDescription>
              Esta herramienta está en desarrollo activo
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center py-12">
              <QrCode className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-lg font-semibold mb-2">Próximamente</h3>
              <p className="text-muted-foreground">
                El generador de códigos QR estará disponible en la próxima actualización
              </p>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
