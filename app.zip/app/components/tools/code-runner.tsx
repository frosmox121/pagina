
'use client'

import { useState, useRef, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  Play, 
  Square, 
  Copy, 
  Save, 
  Mail, 
  Code2, 
  Terminal, 
  Check, 
  AlertCircle, 
  RefreshCw,
  History,
  FileText
} from 'lucide-react'
import { motion } from 'framer-motion'

interface CodeTemplate {
  language: string
  name: string
  code: string
}

interface ExecutionResult {
  success: boolean
  output?: string
  error?: string
  executionTime?: number
  emailSent?: boolean
}

export function CodeRunner() {
  const { data: session } = useSession()
  const [code, setCode] = useState('')
  const [language, setLanguage] = useState('python')
  const [output, setOutput] = useState('')
  const [isExecuting, setIsExecuting] = useState(false)
  const [isSendingEmail, setIsSendingEmail] = useState(false)
  const [executionResult, setExecutionResult] = useState<ExecutionResult | null>(null)
  const [copiedOutput, setCopiedOutput] = useState(false)
  const [emailStatus, setEmailStatus] = useState<'idle' | 'sending' | 'sent' | 'error'>('idle')
  const [history, setHistory] = useState<any[]>([])
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  const codeTemplates: CodeTemplate[] = [
    {
      language: 'python',
      name: 'Hola Mundo',
      code: '# Programa básico en Python\nprint("¡Hola, DevTools!")\n\n# Variables y operaciones\nnombre = "Desarrollador"\nedad = 25\nprint(f"Hola {nombre}, tienes {edad} años")\n\n# Lista y bucle\nnumeros = [1, 2, 3, 4, 5]\nfor num in numeros:\n    print(f"Número: {num}")'
    },
    {
      language: 'python',
      name: 'Calculadora',
      code: '# Calculadora simple\ndef calculadora(a, b, operacion):\n    if operacion == "suma":\n        return a + b\n    elif operacion == "resta":\n        return a - b\n    elif operacion == "multiplicacion":\n        return a * b\n    elif operacion == "division":\n        return a / b if b != 0 else "Error: División por cero"\n    else:\n        return "Operación no válida"\n\n# Pruebas\nprint("=== Calculadora DevTools ===")\nprint(f"5 + 3 = {calculadora(5, 3, \'suma\')}")\nprint(f"10 - 4 = {calculadora(10, 4, \'resta\')}")\nprint(f"6 * 7 = {calculadora(6, 7, \'multiplicacion\')}")\nprint(f"15 / 3 = {calculadora(15, 3, \'division\')}")'
    },
    {
      language: 'csharp',
      name: 'Hola Mundo',
      code: 'using System;\nusing System.Collections.Generic;\n\nclass Program\n{\n    static void Main()\n    {\n        // Programa básico en C#\n        Console.WriteLine("¡Hola, DevTools!");\n        \n        // Variables y operaciones\n        string nombre = "Desarrollador";\n        int edad = 25;\n        Console.WriteLine($"Hola {nombre}, tienes {edad} años");\n        \n        // Lista y bucle\n        List<int> numeros = new List<int> {1, 2, 3, 4, 5};\n        foreach (int num in numeros)\n        {\n            Console.WriteLine($"Número: {num}");\n        }\n    }\n}'
    },
    {
      language: 'csharp',
      name: 'Calculadora',
      code: 'using System;\n\nclass Program\n{\n    static double Calculadora(double a, double b, string operacion)\n    {\n        switch (operacion.ToLower())\n        {\n            case "suma":\n                return a + b;\n            case "resta":\n                return a - b;\n            case "multiplicacion":\n                return a * b;\n            case "division":\n                return b != 0 ? a / b : double.NaN;\n            default:\n                return double.NaN;\n        }\n    }\n    \n    static void Main()\n    {\n        Console.WriteLine("=== Calculadora DevTools ===");\n        Console.WriteLine($"5 + 3 = {Calculadora(5, 3, \\"suma\\")}");\n        Console.WriteLine($"10 - 4 = {Calculadora(10, 4, \\"resta\\")}");\n        Console.WriteLine($"6 * 7 = {Calculadora(6, 7, \\"multiplicacion\\")}");\n        Console.WriteLine($"15 / 3 = {Calculadora(15, 3, \\"division\\")}");\n    }\n}'
    },
    {
      language: 'cpp',
      name: 'Hola Mundo',
      code: '#include <iostream>\n#include <vector>\n#include <string>\n\nusing namespace std;\n\nint main() {\n    // Programa básico en C++\n    cout << "¡Hola, DevTools!" << endl;\n    \n    // Variables y operaciones\n    string nombre = "Desarrollador";\n    int edad = 25;\n    cout << "Hola " << nombre << ", tienes " << edad << " años" << endl;\n    \n    // Vector y bucle\n    vector<int> numeros = {1, 2, 3, 4, 5};\n    for (int num : numeros) {\n        cout << "Número: " << num << endl;\n    }\n    \n    return 0;\n}'
    },
    {
      language: 'cpp',
      name: 'Calculadora',
      code: '#include <iostream>\n#include <string>\n\nusing namespace std;\n\ndouble calculadora(double a, double b, const string& operacion) {\n    if (operacion == "suma") {\n        return a + b;\n    } else if (operacion == "resta") {\n        return a - b;\n    } else if (operacion == "multiplicacion") {\n        return a * b;\n    } else if (operacion == "division") {\n        return b != 0 ? a / b : 0;\n    }\n    return 0;\n}\n\nint main() {\n    cout << "=== Calculadora DevTools ===" << endl;\n    cout << "5 + 3 = " << calculadora(5, 3, "suma") << endl;\n    cout << "10 - 4 = " << calculadora(10, 4, "resta") << endl;\n    cout << "6 * 7 = " << calculadora(6, 7, "multiplicacion") << endl;\n    cout << "15 / 3 = " << calculadora(15, 3, "division") << endl;\n    \n    return 0;\n}'
    }
  ]

  const languageConfigs = {
    python: {
      name: 'Python',
      icon: '🐍',
      color: 'bg-blue-500',
      description: 'Python 3.9+',
      extension: '.py'
    },
    csharp: {
      name: 'C#',
      icon: '⚡',
      color: 'bg-purple-500',
      description: '.NET 6+',
      extension: '.cs'
    },
    cpp: {
      name: 'C++',
      icon: '🔥',
      color: 'bg-orange-500',
      description: 'C++17',
      extension: '.cpp'
    }
  }

  const executeCode = async () => {
    if (!code.trim()) {
      setExecutionResult({
        success: false,
        error: 'Por favor ingresa código para ejecutar'
      })
      return
    }

    setIsExecuting(true)
    setOutput('')
    setExecutionResult(null)

    try {
      const response = await fetch('/api/code/execute', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          code,
          language
        }),
      })

      if (!response.ok) {
        throw new Error('Error en la ejecución del código')
      }

      const reader = response.body?.getReader()
      const decoder = new TextDecoder()
      let fullOutput = ''

      if (reader) {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          
          const chunk = decoder.decode(value)
          const lines = chunk.split('\n')
          
          for (const line of lines) {
            if (line.startsWith('data: ')) {
              const data = line.slice(6)
              if (data === '[DONE]') {
                continue
              }
              
              try {
                const parsed = JSON.parse(data)
                if (parsed.content) {
                  fullOutput += parsed.content
                  setOutput(prev => prev + parsed.content)
                }
              } catch (e) {
                // Skip invalid JSON
              }
            }
          }
        }
      }

      // Parse the final result to determine success/failure
      const result: ExecutionResult = {
        success: !fullOutput.toLowerCase().includes('error:') && 
                !fullOutput.toLowerCase().includes('exception:') &&
                !fullOutput.toLowerCase().includes('traceback:'),
        output: fullOutput,
        executionTime: Date.now()
      }

      setExecutionResult(result)

      // Add to history
      const newHistoryItem = {
        id: Date.now(),
        language,
        code: code.substring(0, 100) + (code.length > 100 ? '...' : ''),
        timestamp: new Date().toLocaleString(),
        success: result.success
      }
      setHistory(prev => [newHistoryItem, ...prev.slice(0, 9)]) // Keep last 10

    } catch (error) {
      console.error('Code execution error:', error)
      setExecutionResult({
        success: false,
        error: 'Error al ejecutar el código. Intenta nuevamente.'
      })
    } finally {
      setIsExecuting(false)
    }
  }

  const sendCodeByEmail = async () => {
    if (!session?.user?.email || !code.trim()) return

    setEmailStatus('sending')
    setIsSendingEmail(true)

    try {
      const response = await fetch('/api/code/send-email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          code,
          language,
          output: output || 'Sin salida',
          userEmail: session.user.email,
          userName: session.user.name || 'Usuario'
        }),
      })

      if (response.ok) {
        setEmailStatus('sent')
        setExecutionResult(prev => prev ? { ...prev, emailSent: true } : null)
      } else {
        setEmailStatus('error')
      }
    } catch (error) {
      console.error('Email sending error:', error)
      setEmailStatus('error')
    } finally {
      setIsSendingEmail(false)
      setTimeout(() => setEmailStatus('idle'), 3000)
    }
  }

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(output)
      setCopiedOutput(true)
      setTimeout(() => setCopiedOutput(false), 2000)
    } catch (err) {
      console.error('Failed to copy output: ', err)
    }
  }

  const loadTemplate = (template: CodeTemplate) => {
    setLanguage(template.language)
    setCode(template.code)
    setOutput('')
    setExecutionResult(null)
  }

  const clearAll = () => {
    setCode('')
    setOutput('')
    setExecutionResult(null)
  }

  const getCurrentTemplate = () => {
    return codeTemplates.find(t => t.language === language && t.name === 'Hola Mundo')
  }

  const currentTemplate = getCurrentTemplate()
  const langConfig = languageConfigs[language as keyof typeof languageConfigs]

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-2xl bg-blue-500 flex items-center justify-center">
              <Code2 className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            💻 Ejecutor de Código
          </h1>
          <p className="text-lg text-muted-foreground">
            Ejecuta código Python, C# y C++ en línea con análisis inteligente y envío por email
          </p>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          {/* Code Editor Section */}
          <div className="xl:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Code2 className="h-5 w-5" />
                    <CardTitle>Editor de Código</CardTitle>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={`${langConfig.color} text-white`}>
                      {langConfig.icon} {langConfig.name}
                    </Badge>
                  </div>
                </div>
                <CardDescription>
                  Escribe tu código {langConfig.name} aquí
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="language">Lenguaje</Label>
                  <Select value={language} onValueChange={setLanguage}>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona un lenguaje" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(languageConfigs).map(([key, config]) => (
                        <SelectItem key={key} value={key}>
                          {config.icon} {config.name} - {config.description}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="code">Código</Label>
                  <Textarea
                    id="code"
                    ref={textareaRef}
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    placeholder={`Escribe tu código ${langConfig.name} aquí...`}
                    className="min-h-[400px] font-mono text-sm resize-none"
                    style={{ 
                      fontSize: '14px',
                      lineHeight: '1.5',
                      fontFamily: '"Fira Code", "Consolas", "Monaco", monospace'
                    }}
                  />
                </div>

                <div className="flex flex-wrap gap-2">
                  <Button 
                    onClick={executeCode} 
                    disabled={isExecuting || !code.trim()}
                    className="flex-1 min-w-[120px]"
                  >
                    {isExecuting ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Ejecutando...
                      </>
                    ) : (
                      <>
                        <Play className="mr-2 h-4 w-4" />
                        Ejecutar
                      </>
                    )}
                  </Button>
                  
                  <Button
                    onClick={sendCodeByEmail}
                    disabled={isSendingEmail || !code.trim() || !session?.user?.email}
                    variant="outline"
                  >
                    {emailStatus === 'sending' ? (
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary mr-2"></div>
                    ) : emailStatus === 'sent' ? (
                      <Check className="mr-2 h-4 w-4 text-green-500" />
                    ) : (
                      <Mail className="mr-2 h-4 w-4" />
                    )}
                    {emailStatus === 'sending' ? 'Enviando...' : 
                     emailStatus === 'sent' ? 'Enviado' : 'Enviar por Email'}
                  </Button>
                  
                  <Button onClick={clearAll} variant="outline">
                    Limpiar
                  </Button>
                </div>

                {emailStatus === 'sent' && (
                  <Alert>
                    <Check className="h-4 w-4" />
                    <AlertDescription>
                      Código enviado exitosamente a {session?.user?.email}
                    </AlertDescription>
                  </Alert>
                )}

                {emailStatus === 'error' && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      Error al enviar el email. Intenta nuevamente.
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>

            {/* Output Section */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Terminal className="h-5 w-5" />
                    <CardTitle>Salida</CardTitle>
                  </div>
                  {output && (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={copyToClipboard}
                    >
                      {copiedOutput ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    </Button>
                  )}
                </div>
                <CardDescription>
                  Resultado de la ejecución del código
                </CardDescription>
              </CardHeader>
              <CardContent>
                {executionResult ? (
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <Badge variant={executionResult.success ? 'default' : 'destructive'}>
                        {executionResult.success ? 'Éxito' : 'Error'}
                      </Badge>
                      {executionResult.emailSent && (
                        <Badge variant="secondary">
                          <Mail className="mr-1 h-3 w-3" />
                          Email Enviado
                        </Badge>
                      )}
                    </div>
                    
                    <div className="p-4 bg-muted rounded-lg">
                      <pre className="text-sm font-mono whitespace-pre-wrap">
                        {output || executionResult.error || 'Sin salida'}
                      </pre>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    <Terminal className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>La salida aparecerá aquí</p>
                    <p className="text-sm mt-2">Ejecuta tu código para ver los resultados</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Templates */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Plantillas
                </CardTitle>
                <CardDescription>
                  Ejemplos de código para comenzar
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {codeTemplates
                    .filter(template => template.language === language)
                    .map((template, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        className="w-full justify-start"
                        onClick={() => loadTemplate(template)}
                      >
                        <Code2 className="mr-2 h-4 w-4" />
                        {template.name}
                      </Button>
                    ))}
                </div>
              </CardContent>
            </Card>

            {/* History */}
            {history.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <History className="h-5 w-5" />
                    Historial
                  </CardTitle>
                  <CardDescription>
                    Últimas ejecuciones
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {history.slice(0, 5).map((item) => (
                      <div key={item.id} className="p-3 bg-muted rounded-lg">
                        <div className="flex items-center justify-between mb-1">
                          <Badge variant="outline" className="text-xs">
                            {languageConfigs[item.language as keyof typeof languageConfigs]?.icon} {
                              languageConfigs[item.language as keyof typeof languageConfigs]?.name
                            }
                          </Badge>
                          <Badge variant={item.success ? 'default' : 'destructive'} className="text-xs">
                            {item.success ? '✓' : '✗'}
                          </Badge>
                        </div>
                        <p className="text-xs font-mono text-muted-foreground truncate">
                          {item.code}
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {item.timestamp}
                        </p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Language Info */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <span className="text-lg">{langConfig.icon}</span>
                  {langConfig.name}
                </CardTitle>
                <CardDescription>
                  {langConfig.description}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Extensión:</span>
                    <span className="font-mono">{langConfig.extension}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Ejecutor:</span>
                    <span>IA Asistente</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Timeout:</span>
                    <span>30 segundos</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <Alert className="mt-6">
          <Code2 className="h-4 w-4" />
          <AlertDescription>
            <strong>Funcionalidad Premium:</strong> Tu código se ejecuta de forma segura usando IA avanzada. 
            {session?.user?.email && ` Los resultados se pueden enviar a ${session.user.email}.`}
          </AlertDescription>
        </Alert>
      </motion.div>
    </div>
  )
}
