

'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Calculator, RotateCcw, Percent } from 'lucide-react'
import { motion } from 'framer-motion'

export function PercentageCalculator() {
  // Basic percentage calculations
  const [value, setValue] = useState('')
  const [percentage, setPercentage] = useState('')
  const [basicResult, setBasicResult] = useState('')

  // Percentage of total
  const [part, setPart] = useState('')
  const [total, setTotal] = useState('')
  const [partResult, setPartResult] = useState('')

  // Percentage change
  const [oldValue, setOldValue] = useState('')
  const [newValue, setNewValue] = useState('')
  const [changeResult, setChangeResult] = useState('')

  // Percentage increase/decrease
  const [baseValue, setBaseValue] = useState('')
  const [changePercent, setChangePercent] = useState('')
  const [increaseResult, setIncreaseResult] = useState('')
  const [decreaseResult, setDecreaseResult] = useState('')

  // Calculate percentage of value
  useEffect(() => {
    if (value && percentage) {
      const val = parseFloat(value)
      const perc = parseFloat(percentage)
      if (!isNaN(val) && !isNaN(perc)) {
        const result = (val * perc) / 100
        setBasicResult(result.toString())
      }
    } else {
      setBasicResult('')
    }
  }, [value, percentage])

  // Calculate what percentage a part is of total
  useEffect(() => {
    if (part && total) {
      const partVal = parseFloat(part)
      const totalVal = parseFloat(total)
      if (!isNaN(partVal) && !isNaN(totalVal) && totalVal !== 0) {
        const result = (partVal / totalVal) * 100
        setPartResult(result.toFixed(2) + '%')
      }
    } else {
      setPartResult('')
    }
  }, [part, total])

  // Calculate percentage change
  useEffect(() => {
    if (oldValue && newValue) {
      const oldVal = parseFloat(oldValue)
      const newVal = parseFloat(newValue)
      if (!isNaN(oldVal) && !isNaN(newVal) && oldVal !== 0) {
        const change = ((newVal - oldVal) / oldVal) * 100
        const isIncrease = change > 0
        setChangeResult(`${isIncrease ? '+' : ''}${change.toFixed(2)}%`)
      }
    } else {
      setChangeResult('')
    }
  }, [oldValue, newValue])

  // Calculate increase/decrease
  useEffect(() => {
    if (baseValue && changePercent) {
      const base = parseFloat(baseValue)
      const percent = parseFloat(changePercent)
      if (!isNaN(base) && !isNaN(percent)) {
        const increase = base + (base * percent) / 100
        const decrease = base - (base * percent) / 100
        setIncreaseResult(increase.toString())
        setDecreaseResult(decrease.toString())
      }
    } else {
      setIncreaseResult('')
      setDecreaseResult('')
    }
  }, [baseValue, changePercent])

  const resetAll = () => {
    setValue('')
    setPercentage('')
    setPart('')
    setTotal('')
    setOldValue('')
    setNewValue('')
    setBaseValue('')
    setChangePercent('')
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-2xl bg-green-500 flex items-center justify-center">
              <Percent className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            📊 Calculadora de Porcentajes
          </h1>
          <p className="text-lg text-muted-foreground">
            Realiza diferentes tipos de cálculos de porcentajes de forma rápida y precisa
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Column */}
          <div className="space-y-6">
            {/* Basic Percentage */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calculator className="h-5 w-5" />
                  Porcentaje de un Valor
                </CardTitle>
                <CardDescription>
                  Calcula el X% de un número
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-4 items-end">
                  <div className="space-y-2">
                    <Label htmlFor="percentage">Porcentaje (%)</Label>
                    <Input
                      id="percentage"
                      type="number"
                      placeholder="25"
                      value={percentage}
                      onChange={(e) => setPercentage(e.target.value)}
                    />
                  </div>
                  <div className="text-center">
                    <span className="text-lg font-medium">de</span>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="value">Valor</Label>
                    <Input
                      id="value"
                      type="number"
                      placeholder="200"
                      value={value}
                      onChange={(e) => setValue(e.target.value)}
                    />
                  </div>
                </div>
                {basicResult && (
                  <div className="p-4 bg-muted rounded-lg">
                    <div className="text-center">
                      <div className="text-sm text-muted-foreground">Resultado:</div>
                      <div className="text-2xl font-bold text-green-600">
                        {basicResult}
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Percentage of Total */}
            <Card>
              <CardHeader>
                <CardTitle>¿Qué Porcentaje es?</CardTitle>
                <CardDescription>
                  Calcula qué porcentaje representa una parte del total
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-4 items-end">
                  <div className="space-y-2">
                    <Label htmlFor="part">Parte</Label>
                    <Input
                      id="part"
                      type="number"
                      placeholder="50"
                      value={part}
                      onChange={(e) => setPart(e.target.value)}
                    />
                  </div>
                  <div className="text-center">
                    <span className="text-lg font-medium">de</span>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="total">Total</Label>
                    <Input
                      id="total"
                      type="number"
                      placeholder="200"
                      value={total}
                      onChange={(e) => setTotal(e.target.value)}
                    />
                  </div>
                </div>
                {partResult && (
                  <div className="p-4 bg-muted rounded-lg">
                    <div className="text-center">
                      <div className="text-sm text-muted-foreground">Resultado:</div>
                      <div className="text-2xl font-bold text-blue-600">
                        {partResult}
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Percentage Change */}
            <Card>
              <CardHeader>
                <CardTitle>Cambio Porcentual</CardTitle>
                <CardDescription>
                  Calcula el porcentaje de cambio entre dos valores
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="oldValue">Valor Original</Label>
                    <Input
                      id="oldValue"
                      type="number"
                      placeholder="100"
                      value={oldValue}
                      onChange={(e) => setOldValue(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="newValue">Valor Nuevo</Label>
                    <Input
                      id="newValue"
                      type="number"
                      placeholder="120"
                      value={newValue}
                      onChange={(e) => setNewValue(e.target.value)}
                    />
                  </div>
                </div>
                {changeResult && (
                  <div className="p-4 bg-muted rounded-lg">
                    <div className="text-center">
                      <div className="text-sm text-muted-foreground">Cambio:</div>
                      <div className={`text-2xl font-bold ${
                        changeResult.startsWith('+') ? 'text-green-600' : 
                        changeResult.startsWith('-') ? 'text-red-600' : 'text-gray-600'
                      }`}>
                        {changeResult}
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Percentage Increase/Decrease */}
            <Card>
              <CardHeader>
                <CardTitle>Aumentar/Disminuir por Porcentaje</CardTitle>
                <CardDescription>
                  Calcula el resultado de aumentar o disminuir un valor por un porcentaje
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="baseValue">Valor Base</Label>
                    <Input
                      id="baseValue"
                      type="number"
                      placeholder="100"
                      value={baseValue}
                      onChange={(e) => setBaseValue(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="changePercent">Porcentaje (%)</Label>
                    <Input
                      id="changePercent"
                      type="number"
                      placeholder="20"
                      value={changePercent}
                      onChange={(e) => setChangePercent(e.target.value)}
                    />
                  </div>
                </div>
                {(increaseResult || decreaseResult) && (
                  <div className="space-y-3">
                    {increaseResult && (
                      <div className="p-4 bg-green-50 dark:bg-green-950 rounded-lg">
                        <div className="text-center">
                          <div className="text-sm text-muted-foreground">Aumentar:</div>
                          <div className="text-xl font-bold text-green-600">
                            {increaseResult}
                          </div>
                        </div>
                      </div>
                    )}
                    {decreaseResult && (
                      <div className="p-4 bg-red-50 dark:bg-red-950 rounded-lg">
                        <div className="text-center">
                          <div className="text-sm text-muted-foreground">Disminuir:</div>
                          <div className="text-xl font-bold text-red-600">
                            {decreaseResult}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Reset Button */}
        <div className="text-center mt-8">
          <Button onClick={resetAll} variant="outline">
            <RotateCcw className="mr-2 h-4 w-4" />
            Limpiar Todo
          </Button>
        </div>

        {/* Quick Examples */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Ejemplos Rápidos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
              <div className="p-3 bg-muted rounded-lg">
                <div className="font-semibold mb-1">IVA (21%)</div>
                <div className="text-muted-foreground">$100 + 21% = $121</div>
              </div>
              <div className="p-3 bg-muted rounded-lg">
                <div className="font-semibold mb-1">Descuento (15%)</div>
                <div className="text-muted-foreground">$100 - 15% = $85</div>
              </div>
              <div className="p-3 bg-muted rounded-lg">
                <div className="font-semibold mb-1">Propina (10%)</div>
                <div className="text-muted-foreground">10% de $50 = $5</div>
              </div>
              <div className="p-3 bg-muted rounded-lg">
                <div className="font-semibold mb-1">Cambio</div>
                <div className="text-muted-foreground">$100→$120 = +20%</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
