

'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Copy, RefreshCw, Palette, Download, Upload } from 'lucide-react'
import { motion } from 'framer-motion'
import { useToast } from '@/hooks/use-toast'

interface Color {
  hex: string
  rgb: { r: number; g: number; b: number }
  hsl: { h: number; s: number; l: number }
  name?: string
}

type PaletteType = 'monochromatic' | 'analogous' | 'complementary' | 'triadic' | 'tetradic' | 'random'

export function ColorPalette() {
  const { toast } = useToast()
  const [baseColor, setBaseColor] = useState('#3B82F6')
  const [paletteType, setPaletteType] = useState<PaletteType>('complementary')
  const [palette, setPalette] = useState<Color[]>([])
  const [favorites, setFavorites] = useState<Color[]>([])

  // Convert hex to RGB
  const hexToRgb = (hex: string): { r: number; g: number; b: number } => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex)
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : { r: 0, g: 0, b: 0 }
  }

  // Convert RGB to HSL
  const rgbToHsl = (r: number, g: number, b: number): { h: number; s: number; l: number } => {
    r /= 255
    g /= 255
    b /= 255

    const max = Math.max(r, g, b)
    const min = Math.min(r, g, b)
    let h = 0, s = 0
    const l = (max + min) / 2

    if (max === min) {
      h = s = 0
    } else {
      const d = max - min
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min)
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break
        case g: h = (b - r) / d + 2; break
        case b: h = (r - g) / d + 4; break
      }
      h /= 6
    }

    return { h: h * 360, s: s * 100, l: l * 100 }
  }

  // Convert HSL to hex
  const hslToHex = (h: number, s: number, l: number): string => {
    h /= 360
    s /= 100
    l /= 100

    const hue2rgb = (p: number, q: number, t: number) => {
      if (t < 0) t += 1
      if (t > 1) t -= 1
      if (t < 1/6) return p + (q - p) * 6 * t
      if (t < 1/2) return q
      if (t < 2/3) return p + (q - p) * (2/3 - t) * 6
      return p
    }

    const q = l < 0.5 ? l * (1 + s) : l + s - l * s
    const p = 2 * l - q
    const r = hue2rgb(p, q, h + 1/3)
    const g = hue2rgb(p, q, h)
    const b = hue2rgb(p, q, h - 1/3)

    const toHex = (c: number) => {
      const hex = Math.round(c * 255).toString(16)
      return hex.length === 1 ? '0' + hex : hex
    }

    return `#${toHex(r)}${toHex(g)}${toHex(b)}`
  }

  // Generate color palette based on type
  const generatePalette = (baseHex: string, type: PaletteType): Color[] => {
    const rgb = hexToRgb(baseHex)
    const hsl = rgbToHsl(rgb.r, rgb.g, rgb.b)
    const colors: Color[] = []

    // Always include the base color
    colors.push({
      hex: baseHex,
      rgb,
      hsl,
      name: 'Base'
    })

    switch (type) {
      case 'monochromatic':
        // Different lightness values
        const lightness = [20, 40, 60, 80]
        lightness.forEach(l => {
          const hex = hslToHex(hsl.h, hsl.s, l)
          colors.push({
            hex,
            rgb: hexToRgb(hex),
            hsl: { ...hsl, l }
          })
        })
        break

      case 'analogous':
        // Adjacent hues
        const analogousHues = [-30, -15, 15, 30]
        analogousHues.forEach(offset => {
          const newHue = (hsl.h + offset + 360) % 360
          const hex = hslToHex(newHue, hsl.s, hsl.l)
          colors.push({
            hex,
            rgb: hexToRgb(hex),
            hsl: { ...hsl, h: newHue }
          })
        })
        break

      case 'complementary':
        // Opposite hue
        const compHue = (hsl.h + 180) % 360
        const compHex = hslToHex(compHue, hsl.s, hsl.l)
        colors.push({
          hex: compHex,
          rgb: hexToRgb(compHex),
          hsl: { ...hsl, h: compHue },
          name: 'Complementary'
        })

        // Add variations
        const variations = [
          { h: hsl.h, s: hsl.s * 0.7, l: hsl.l * 1.2 },
          { h: hsl.h, s: hsl.s * 1.3, l: hsl.l * 0.8 },
          { h: compHue, s: hsl.s * 0.7, l: hsl.l * 1.2 },
          { h: compHue, s: hsl.s * 1.3, l: hsl.l * 0.8 }
        ]
        
        variations.forEach(variation => {
          const hex = hslToHex(variation.h, Math.min(variation.s, 100), Math.min(variation.l, 100))
          colors.push({
            hex,
            rgb: hexToRgb(hex),
            hsl: variation
          })
        })
        break

      case 'triadic':
        // Three equally spaced hues
        const triadicHues = [120, 240]
        triadicHues.forEach(offset => {
          const newHue = (hsl.h + offset) % 360
          const hex = hslToHex(newHue, hsl.s, hsl.l)
          colors.push({
            hex,
            rgb: hexToRgb(hex),
            hsl: { ...hsl, h: newHue }
          })
        })

        // Add lighter and darker variants
        colors.forEach((color, index) => {
          if (index < 3) {
            const lightHex = hslToHex(color.hsl.h, color.hsl.s, Math.min(color.hsl.l + 20, 95))
            const darkHex = hslToHex(color.hsl.h, color.hsl.s, Math.max(color.hsl.l - 20, 5))
            colors.push(
              { hex: lightHex, rgb: hexToRgb(lightHex), hsl: { ...color.hsl, l: Math.min(color.hsl.l + 20, 95) } },
              { hex: darkHex, rgb: hexToRgb(darkHex), hsl: { ...color.hsl, l: Math.max(color.hsl.l - 20, 5) } }
            )
          }
        })
        break

      case 'tetradic':
        // Two pairs of complementary colors
        const tetradicHues = [90, 180, 270]
        tetradicHues.forEach(offset => {
          const newHue = (hsl.h + offset) % 360
          const hex = hslToHex(newHue, hsl.s, hsl.l)
          colors.push({
            hex,
            rgb: hexToRgb(hex),
            hsl: { ...hsl, h: newHue }
          })
        })
        break

      case 'random':
        // Generate random colors
        for (let i = 0; i < 8; i++) {
          const randomHue = Math.floor(Math.random() * 360)
          const randomSat = 40 + Math.floor(Math.random() * 60)
          const randomLight = 30 + Math.floor(Math.random() * 50)
          const hex = hslToHex(randomHue, randomSat, randomLight)
          colors.push({
            hex,
            rgb: hexToRgb(hex),
            hsl: { h: randomHue, s: randomSat, l: randomLight }
          })
        }
        break
    }

    return colors
  }

  const copyColor = async (color: Color, format: 'hex' | 'rgb' | 'hsl') => {
    let textToCopy = ''
    
    switch (format) {
      case 'hex':
        textToCopy = color.hex
        break
      case 'rgb':
        textToCopy = `rgb(${color.rgb.r}, ${color.rgb.g}, ${color.rgb.b})`
        break
      case 'hsl':
        textToCopy = `hsl(${Math.round(color.hsl.h)}, ${Math.round(color.hsl.s)}%, ${Math.round(color.hsl.l)}%)`
        break
    }

    try {
      await navigator.clipboard.writeText(textToCopy)
      toast({
        title: "¡Copiado!",
        description: `Color copiado: ${textToCopy}`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo copiar al portapapeles.",
        variant: "destructive",
      })
    }
  }

  const addToFavorites = (color: Color) => {
    if (!favorites.find(fav => fav.hex === color.hex)) {
      setFavorites(prev => [...prev, color])
      toast({
        title: "Agregado a favoritos",
        description: `Color ${color.hex} guardado`,
      })
    }
  }

  const exportPalette = () => {
    const paletteData = {
      baseColor,
      type: paletteType,
      colors: palette.map(color => ({
        hex: color.hex,
        rgb: color.rgb,
        hsl: color.hsl,
        name: color.name
      })),
      createdAt: new Date().toISOString()
    }

    const dataStr = JSON.stringify(paletteData, null, 2)
    const dataBlob = new Blob([dataStr], { type: 'application/json' })
    const url = URL.createObjectURL(dataBlob)
    
    const link = document.createElement('a')
    link.href = url
    link.download = `palette-${Date.now()}.json`
    link.click()
    
    URL.revokeObjectURL(url)
  }

  useEffect(() => {
    const newPalette = generatePalette(baseColor, paletteType)
    setPalette(newPalette)
  }, [baseColor, paletteType])

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-2xl bg-rose-500 flex items-center justify-center">
              <Palette className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            🎨 Generador de Paletas de Colores
          </h1>
          <p className="text-lg text-muted-foreground">
            Crea paletas de colores armoniosas para tus proyectos de diseño
          </p>
        </div>

        {/* Controls */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Configuración de Paleta</CardTitle>
            <CardDescription>
              Selecciona un color base y el tipo de armonía que deseas generar
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <Label htmlFor="baseColor">Color Base</Label>
                <div className="flex gap-2">
                  <Input
                    id="baseColor"
                    type="color"
                    value={baseColor}
                    onChange={(e) => setBaseColor(e.target.value)}
                    className="w-16 h-10 p-1 border rounded"
                  />
                  <Input
                    type="text"
                    value={baseColor}
                    onChange={(e) => setBaseColor(e.target.value)}
                    placeholder="#3B82F6"
                    className="flex-1"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Tipo de Paleta</Label>
                <Select value={paletteType} onValueChange={(value: PaletteType) => setPaletteType(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="monochromatic">Monocromática</SelectItem>
                    <SelectItem value="analogous">Análoga</SelectItem>
                    <SelectItem value="complementary">Complementaria</SelectItem>
                    <SelectItem value="triadic">Triádica</SelectItem>
                    <SelectItem value="tetradic">Tetrádica</SelectItem>
                    <SelectItem value="random">Aleatoria</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-end gap-2">
                <Button onClick={() => setPalette(generatePalette(baseColor, paletteType))} variant="outline">
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Regenerar
                </Button>
                <Button onClick={exportPalette} variant="outline">
                  <Download className="mr-2 h-4 w-4" />
                  Exportar
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Generated Palette */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Paleta Generada</CardTitle>
            <CardDescription>
              Haz clic en cualquier color para copiarlo en diferentes formatos
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {palette.map((color, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  className="group"
                >
                  <div
                    className="w-full h-24 rounded-lg cursor-pointer shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
                    style={{ backgroundColor: color.hex }}
                    onClick={() => copyColor(color, 'hex')}
                  />
                  <div className="mt-3 space-y-2">
                    <div className="text-center">
                      <div className="font-mono text-sm font-semibold">{color.hex}</div>
                      {color.name && (
                        <Badge variant="outline" className="text-xs">
                          {color.name}
                        </Badge>
                      )}
                    </div>
                    <div className="flex gap-1">
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="flex-1 text-xs"
                        onClick={() => copyColor(color, 'hex')}
                      >
                        HEX
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="flex-1 text-xs"
                        onClick={() => copyColor(color, 'rgb')}
                      >
                        RGB
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="flex-1 text-xs"
                        onClick={() => copyColor(color, 'hsl')}
                      >
                        HSL
                      </Button>
                    </div>
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      className="w-full text-xs"
                      onClick={() => addToFavorites(color)}
                    >
                      ⭐ Favorito
                    </Button>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Favorites */}
        {favorites.length > 0 && (
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Colores Favoritos</CardTitle>
                  <CardDescription>
                    Colores que has guardado para uso futuro
                  </CardDescription>
                </div>
                <Button 
                  onClick={() => setFavorites([])} 
                  variant="outline" 
                  size="sm"
                >
                  Limpiar Todo
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-6 md:grid-cols-10 lg:grid-cols-15 gap-2">
                {favorites.map((color, index) => (
                  <div
                    key={index}
                    className="group relative"
                  >
                    <div
                      className="w-12 h-12 rounded cursor-pointer shadow hover:shadow-lg transition-all duration-300 hover:scale-110"
                      style={{ backgroundColor: color.hex }}
                      onClick={() => copyColor(color, 'hex')}
                      title={color.hex}
                    />
                    <button
                      className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white rounded-full text-xs opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => setFavorites(prev => prev.filter((_, i) => i !== index))}
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Info */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Tipos de Armonías de Color</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 text-sm">
              <div>
                <h4 className="font-semibold mb-2">Monocromática</h4>
                <p className="text-muted-foreground">
                  Usa diferentes tonos, sombras y tintes del mismo color base.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Análoga</h4>
                <p className="text-muted-foreground">
                  Colores que están uno al lado del otro en la rueda de colores.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Complementaria</h4>
                <p className="text-muted-foreground">
                  Colores que están directamente opuestos en la rueda de colores.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Triádica</h4>
                <p className="text-muted-foreground">
                  Tres colores igualmente espaciados en la rueda de colores.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Tetrádica</h4>
                <p className="text-muted-foreground">
                  Cuatro colores que forman un rectángulo en la rueda de colores.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Aleatoria</h4>
                <p className="text-muted-foreground">
                  Colores generados aleatoriamente para inspiración creativa.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
