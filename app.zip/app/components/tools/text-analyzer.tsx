

'use client'

import { useState, useMemo } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { FileText, RotateCcw, Copy, Upload } from 'lucide-react'
import { motion } from 'framer-motion'
import { useToast } from '@/hooks/use-toast'

interface TextStats {
  characters: number
  charactersNoSpaces: number
  words: number
  sentences: number
  paragraphs: number
  lines: number
  averageWordsPerSentence: number
  averageCharactersPerWord: number
  mostCommonWords: Array<{ word: string; count: number }>
  readingTime: number
  difficultWords: number
}

export function TextAnalyzer() {
  const { toast } = useToast()
  const [text, setText] = useState('')

  const stats: TextStats = useMemo(() => {
    if (!text.trim()) {
      return {
        characters: 0,
        charactersNoSpaces: 0,
        words: 0,
        sentences: 0,
        paragraphs: 0,
        lines: 0,
        averageWordsPerSentence: 0,
        averageCharactersPerWord: 0,
        mostCommonWords: [],
        readingTime: 0,
        difficultWords: 0
      }
    }

    // Basic counts
    const characters = text.length
    const charactersNoSpaces = text.replace(/\s/g, '').length
    const lines = text.split('\n').length
    
    // Paragraphs (separated by double line breaks or empty lines)
    const paragraphs = text.split(/\n\s*\n/).filter(p => p.trim().length > 0).length || 1

    // Words
    const words = text.trim().split(/\s+/).filter(word => word.length > 0)
    const wordCount = words.length

    // Sentences (split by . ! ? but be careful with abbreviations)
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0)
    const sentenceCount = sentences.length

    // Average calculations
    const averageWordsPerSentence = sentenceCount > 0 ? Math.round((wordCount / sentenceCount) * 100) / 100 : 0
    const totalWordLength = words.reduce((sum, word) => sum + word.replace(/[^\w]/g, '').length, 0)
    const averageCharactersPerWord = wordCount > 0 ? Math.round((totalWordLength / wordCount) * 100) / 100 : 0

    // Most common words
    const wordFrequency: { [key: string]: number } = {}
    const cleanWords = words
      .map(word => word.toLowerCase().replace(/[^\w]/g, ''))
      .filter(word => word.length > 2) // Ignore very short words
      .filter(word => !['the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'que', 'de', 'la', 'el', 'en', 'y', 'un', 'es', 'se', 'no', 'te', 'lo', 'le', 'da', 'su', 'por', 'son', 'con', 'una', 'sus', 'las', 'del', 'los', 'como', 'pero', 'sus', 'han', 'era', 'para', 'sobre', 'todo', 'esta', 'ser', 'son', 'dos', 'más', 'muy', 'fue', 'está', 'hasta', 'desde'].includes(word))

    cleanWords.forEach(word => {
      wordFrequency[word] = (wordFrequency[word] || 0) + 1
    })

    const mostCommonWords = Object.entries(wordFrequency)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 10)
      .map(([word, count]) => ({ word, count }))

    // Reading time (average 200 words per minute)
    const readingTime = Math.ceil(wordCount / 200)

    // Difficult words (words with 7+ characters - simplified)
    const difficultWords = words.filter(word => word.replace(/[^\w]/g, '').length >= 7).length

    return {
      characters,
      charactersNoSpaces,
      words: wordCount,
      sentences: sentenceCount,
      paragraphs,
      lines,
      averageWordsPerSentence,
      averageCharactersPerWord,
      mostCommonWords,
      readingTime,
      difficultWords
    }
  }, [text])

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file && file.type === 'text/plain') {
      const reader = new FileReader()
      reader.onload = (e) => {
        const content = e.target?.result as string
        setText(content)
      }
      reader.readAsText(file)
    } else {
      toast({
        title: "Error",
        description: "Por favor selecciona un archivo de texto (.txt)",
        variant: "destructive",
      })
    }
  }

  const copyStats = async () => {
    const statsText = `
Análisis de Texto:
- Caracteres: ${stats.characters}
- Caracteres (sin espacios): ${stats.charactersNoSpaces}
- Palabras: ${stats.words}
- Oraciones: ${stats.sentences}
- Párrafos: ${stats.paragraphs}
- Líneas: ${stats.lines}
- Promedio palabras/oración: ${stats.averageWordsPerSentence}
- Promedio caracteres/palabra: ${stats.averageCharactersPerWord}
- Tiempo de lectura: ${stats.readingTime} min
- Palabras difíciles: ${stats.difficultWords}
    `.trim()

    try {
      await navigator.clipboard.writeText(statsText)
      toast({
        title: "¡Copiado!",
        description: "Las estadísticas han sido copiadas al portapapeles.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo copiar al portapapeles.",
        variant: "destructive",
      })
    }
  }

  const reset = () => {
    setText('')
  }

  const getReadabilityLevel = () => {
    if (stats.averageWordsPerSentence < 15 && stats.averageCharactersPerWord < 5) {
      return { level: 'Fácil', color: 'bg-green-500' }
    } else if (stats.averageWordsPerSentence < 20 && stats.averageCharactersPerWord < 6) {
      return { level: 'Medio', color: 'bg-yellow-500' }
    } else {
      return { level: 'Difícil', color: 'bg-red-500' }
    }
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-2xl bg-purple-500 flex items-center justify-center">
              <FileText className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            📊 Analizador de Texto
          </h1>
          <p className="text-lg text-muted-foreground">
            Analiza estadísticas detalladas de cualquier texto: palabras, oraciones, legibilidad y más
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Input */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Texto a Analizar</CardTitle>
                  <CardDescription>
                    Escribe o pega tu texto aquí, o sube un archivo
                  </CardDescription>
                </div>
                <div className="flex gap-2">
                  <label>
                    <input
                      type="file"
                      accept=".txt"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                    <Button variant="outline" size="sm" asChild>
                      <span>
                        <Upload className="h-4 w-4 mr-1" />
                        Subir
                      </span>
                    </Button>
                  </label>
                  <Button onClick={reset} variant="outline" size="sm">
                    <RotateCcw className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Escribe o pega tu texto aquí para analizarlo..."
                value={text}
                onChange={(e) => setText(e.target.value)}
                rows={15}
                className="resize-none"
              />
              {text && (
                <div className="mt-4 text-xs text-muted-foreground">
                  {stats.characters} caracteres • {stats.words} palabras
                </div>
              )}
            </CardContent>
          </Card>

          {/* Stats */}
          <div className="space-y-6">
            {/* Basic Stats */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Estadísticas Básicas</CardTitle>
                  {text && (
                    <Button onClick={copyStats} size="sm" variant="outline">
                      <Copy className="h-4 w-4 mr-1" />
                      Copiar
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {!text ? (
                  <div className="text-center py-8 text-muted-foreground">
                    Escribe algo para ver las estadísticas
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">{stats.characters}</div>
                      <div className="text-xs text-muted-foreground">Caracteres</div>
                    </div>
                    <div className="text-center p-3 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-green-600">{stats.charactersNoSpaces}</div>
                      <div className="text-xs text-muted-foreground">Sin espacios</div>
                    </div>
                    <div className="text-center p-3 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">{stats.words}</div>
                      <div className="text-xs text-muted-foreground">Palabras</div>
                    </div>
                    <div className="text-center p-3 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-orange-600">{stats.sentences}</div>
                      <div className="text-xs text-muted-foreground">Oraciones</div>
                    </div>
                    <div className="text-center p-3 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-pink-600">{stats.paragraphs}</div>
                      <div className="text-xs text-muted-foreground">Párrafos</div>
                    </div>
                    <div className="text-center p-3 bg-muted rounded-lg">
                      <div className="text-2xl font-bold text-indigo-600">{stats.lines}</div>
                      <div className="text-xs text-muted-foreground">Líneas</div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Advanced Stats */}
            {text && (
              <Card>
                <CardHeader>
                  <CardTitle>Análisis Avanzado</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 gap-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Promedio palabras/oración:</span>
                      <Badge variant="outline">{stats.averageWordsPerSentence}</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Promedio caracteres/palabra:</span>
                      <Badge variant="outline">{stats.averageCharactersPerWord}</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Tiempo de lectura:</span>
                      <Badge variant="outline">{stats.readingTime} min</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Palabras difíciles:</span>
                      <Badge variant="outline">{stats.difficultWords}</Badge>
                    </div>
                    <Separator />
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Nivel de legibilidad:</span>
                      <Badge className={getReadabilityLevel().color}>
                        {getReadabilityLevel().level}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Most Common Words */}
            {text && stats.mostCommonWords.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Palabras Más Frecuentes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {stats.mostCommonWords.map((item, index) => (
                      <div key={index} className="flex justify-between items-center">
                        <span className="text-sm font-mono">{item.word}</span>
                        <div className="flex items-center gap-2">
                          <div className="w-20 bg-muted rounded-full h-2">
                            <div 
                              className="bg-primary h-2 rounded-full"
                              style={{ 
                                width: `${(item.count / stats.mostCommonWords[0].count) * 100}%` 
                              }}
                            />
                          </div>
                          <Badge variant="outline" className="text-xs min-w-[2rem]">
                            {item.count}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Info */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Información sobre el Análisis</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
              <div>
                <h4 className="font-semibold mb-2">Legibilidad:</h4>
                <ul className="space-y-1 text-muted-foreground">
                  <li>• <strong>Fácil:</strong> &lt;15 palabras/oración, &lt;5 caracteres/palabra</li>
                  <li>• <strong>Medio:</strong> 15-20 palabras/oración, 5-6 caracteres/palabra</li>
                  <li>• <strong>Difícil:</strong> &gt;20 palabras/oración, &gt;6 caracteres/palabra</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Tiempo de Lectura:</h4>
                <ul className="space-y-1 text-muted-foreground">
                  <li>• Basado en 200 palabras por minuto</li>
                  <li>• Velocidad promedio de lectura</li>
                  <li>• Incluye tiempo para comprensión</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
