

'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Calendar, RotateCcw, Clock, Plus, Minus } from 'lucide-react'
import { motion } from 'framer-motion'

export function DateCalculator() {
  // Date difference calculation
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [dateDifference, setDateDifference] = useState<{
    years: number
    months: number
    days: number
    totalDays: number
    weeks: number
    hours: number
    minutes: number
  } | null>(null)

  // Add/subtract days calculation
  const [baseDate, setBaseDate] = useState('')
  const [operation, setOperation] = useState<'add' | 'subtract'>('add')
  const [amount, setAmount] = useState('')
  const [unit, setUnit] = useState('days')
  const [resultDate, setResultDate] = useState('')

  // Age calculation
  const [birthDate, setBirthDate] = useState('')
  const [ageResult, setAgeResult] = useState<{
    years: number
    months: number
    days: number
    totalDays: number
    nextBirthday: string
  } | null>(null)

  // Business days calculation
  const [businessStartDate, setBusinessStartDate] = useState('')
  const [businessEndDate, setBusinessEndDate] = useState('')
  const [businessDays, setBusinessDays] = useState(0)

  const calculateDateDifference = () => {
    if (!startDate || !endDate) return

    const start = new Date(startDate)
    const end = new Date(endDate)
    
    if (start > end) {
      // Swap dates if start is after end
      const temp = start
      start.setTime(end.getTime())
      end.setTime(temp.getTime())
    }

    // Calculate total milliseconds difference
    const timeDifference = end.getTime() - start.getTime()
    const totalDays = Math.floor(timeDifference / (1000 * 60 * 60 * 24))
    const weeks = Math.floor(totalDays / 7)
    const hours = Math.floor(timeDifference / (1000 * 60 * 60))
    const minutes = Math.floor(timeDifference / (1000 * 60))

    // Calculate years, months, and days
    let years = end.getFullYear() - start.getFullYear()
    let months = end.getMonth() - start.getMonth()
    let days = end.getDate() - start.getDate()

    if (days < 0) {
      months--
      const lastMonth = new Date(end.getFullYear(), end.getMonth(), 0)
      days += lastMonth.getDate()
    }

    if (months < 0) {
      years--
      months += 12
    }

    setDateDifference({
      years,
      months,
      days,
      totalDays,
      weeks,
      hours,
      minutes
    })
  }

  const calculateResultDate = () => {
    if (!baseDate || !amount) return

    const base = new Date(baseDate)
    const amountNum = parseInt(amount)
    
    if (isNaN(amountNum)) return

    const result = new Date(base)

    switch (unit) {
      case 'days':
        result.setDate(result.getDate() + (operation === 'add' ? amountNum : -amountNum))
        break
      case 'weeks':
        result.setDate(result.getDate() + (operation === 'add' ? amountNum * 7 : -amountNum * 7))
        break
      case 'months':
        result.setMonth(result.getMonth() + (operation === 'add' ? amountNum : -amountNum))
        break
      case 'years':
        result.setFullYear(result.getFullYear() + (operation === 'add' ? amountNum : -amountNum))
        break
    }

    setResultDate(result.toISOString().split('T')[0])
  }

  const calculateAge = () => {
    if (!birthDate) return

    const birth = new Date(birthDate)
    const today = new Date()
    
    // Calculate age
    let years = today.getFullYear() - birth.getFullYear()
    let months = today.getMonth() - birth.getMonth()
    let days = today.getDate() - birth.getDate()

    if (days < 0) {
      months--
      const lastMonth = new Date(today.getFullYear(), today.getMonth(), 0)
      days += lastMonth.getDate()
    }

    if (months < 0) {
      years--
      months += 12
    }

    // Calculate total days lived
    const timeDifference = today.getTime() - birth.getTime()
    const totalDays = Math.floor(timeDifference / (1000 * 60 * 60 * 24))

    // Calculate next birthday
    const nextBirthday = new Date(today.getFullYear(), birth.getMonth(), birth.getDate())
    if (nextBirthday < today) {
      nextBirthday.setFullYear(today.getFullYear() + 1)
    }

    setAgeResult({
      years,
      months,
      days,
      totalDays,
      nextBirthday: nextBirthday.toISOString().split('T')[0]
    })
  }

  const calculateBusinessDays = () => {
    if (!businessStartDate || !businessEndDate) return

    const start = new Date(businessStartDate)
    const end = new Date(businessEndDate)
    
    if (start > end) return

    let count = 0
    const current = new Date(start)

    while (current <= end) {
      const dayOfWeek = current.getDay()
      if (dayOfWeek !== 0 && dayOfWeek !== 6) { // Not Sunday (0) or Saturday (6)
        count++
      }
      current.setDate(current.getDate() + 1)
    }

    setBusinessDays(count)
  }

  const resetAll = () => {
    setStartDate('')
    setEndDate('')
    setDateDifference(null)
    setBaseDate('')
    setAmount('')
    setResultDate('')
    setBirthDate('')
    setAgeResult(null)
    setBusinessStartDate('')
    setBusinessEndDate('')
    setBusinessDays(0)
  }

  useEffect(() => {
    calculateDateDifference()
  }, [startDate, endDate])

  useEffect(() => {
    calculateResultDate()
  }, [baseDate, amount, unit, operation])

  useEffect(() => {
    calculateAge()
  }, [birthDate])

  useEffect(() => {
    calculateBusinessDays()
  }, [businessStartDate, businessEndDate])

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="h-16 w-16 rounded-2xl bg-amber-500 flex items-center justify-center">
              <Calendar className="h-8 w-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight mb-4">
            📅 Calculadora de Fechas
          </h1>
          <p className="text-lg text-muted-foreground">
            Calcula diferencias entre fechas, suma/resta tiempo y más operaciones útiles
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Column */}
          <div className="space-y-6">
            {/* Date Difference */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Diferencia entre Fechas
                </CardTitle>
                <CardDescription>
                  Calcula el tiempo transcurrido entre dos fechas
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="startDate">Fecha de Inicio</Label>
                    <Input
                      id="startDate"
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="endDate">Fecha de Fin</Label>
                    <Input
                      id="endDate"
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                    />
                  </div>
                </div>

                {dateDifference && (
                  <div className="space-y-3">
                    <div className="p-4 bg-muted rounded-lg">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">
                          {dateDifference.years} años, {dateDifference.months} meses, {dateDifference.days} días
                        </div>
                        <div className="text-sm text-muted-foreground mt-2">
                          Equivale a {dateDifference.totalDays} días totales
                        </div>
                      </div>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-sm">
                      <div className="text-center p-2 bg-muted/50 rounded">
                        <div className="font-semibold">{dateDifference.weeks}</div>
                        <div className="text-muted-foreground">Semanas</div>
                      </div>
                      <div className="text-center p-2 bg-muted/50 rounded">
                        <div className="font-semibold">{dateDifference.hours.toLocaleString()}</div>
                        <div className="text-muted-foreground">Horas</div>
                      </div>
                      <div className="text-center p-2 bg-muted/50 rounded">
                        <div className="font-semibold">{dateDifference.minutes.toLocaleString()}</div>
                        <div className="text-muted-foreground">Minutos</div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Add/Subtract Time */}
            <Card>
              <CardHeader>
                <CardTitle>Sumar/Restar Tiempo</CardTitle>
                <CardDescription>
                  Agrega o quita tiempo a una fecha específica
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="baseDate">Fecha Base</Label>
                  <Input
                    id="baseDate"
                    type="date"
                    value={baseDate}
                    onChange={(e) => setBaseDate(e.target.value)}
                  />
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div className="space-y-2">
                    <Label>Operación</Label>
                    <Select value={operation} onValueChange={(value: 'add' | 'subtract') => setOperation(value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="add">
                          <div className="flex items-center gap-1">
                            <Plus className="h-3 w-3" />
                            Sumar
                          </div>
                        </SelectItem>
                        <SelectItem value="subtract">
                          <div className="flex items-center gap-1">
                            <Minus className="h-3 w-3" />
                            Restar
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="amount">Cantidad</Label>
                    <Input
                      id="amount"
                      type="number"
                      placeholder="30"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Unidad</Label>
                    <Select value={unit} onValueChange={setUnit}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="days">Días</SelectItem>
                        <SelectItem value="weeks">Semanas</SelectItem>
                        <SelectItem value="months">Meses</SelectItem>
                        <SelectItem value="years">Años</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {resultDate && (
                  <div className="p-4 bg-muted rounded-lg">
                    <div className="text-center">
                      <div className="text-sm text-muted-foreground">Fecha Resultado:</div>
                      <div className="text-xl font-bold text-green-600">
                        {new Date(resultDate).toLocaleDateString('es-ES', {
                          weekday: 'long',
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Age Calculator */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Calculadora de Edad
                </CardTitle>
                <CardDescription>
                  Calcula tu edad exacta y días vividos
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="birthDate">Fecha de Nacimiento</Label>
                  <Input
                    id="birthDate"
                    type="date"
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                  />
                </div>

                {ageResult && (
                  <div className="space-y-3">
                    <div className="p-4 bg-muted rounded-lg">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-purple-600">
                          {ageResult.years} años, {ageResult.months} meses, {ageResult.days} días
                        </div>
                        <div className="text-sm text-muted-foreground mt-2">
                          Has vivido {ageResult.totalDays.toLocaleString()} días
                        </div>
                      </div>
                    </div>
                    <div className="p-3 bg-yellow-50 dark:bg-yellow-950 rounded-lg">
                      <div className="text-center">
                        <div className="text-sm text-muted-foreground">Próximo Cumpleaños:</div>
                        <div className="font-semibold">
                          {new Date(ageResult.nextBirthday).toLocaleDateString('es-ES', {
                            weekday: 'long',
                            month: 'long',
                            day: 'numeric'
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Business Days */}
            <Card>
              <CardHeader>
                <CardTitle>Días Laborables</CardTitle>
                <CardDescription>
                  Calcula días laborables entre fechas (excluye fines de semana)
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="businessStartDate">Fecha de Inicio</Label>
                    <Input
                      id="businessStartDate"
                      type="date"
                      value={businessStartDate}
                      onChange={(e) => setBusinessStartDate(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="businessEndDate">Fecha de Fin</Label>
                    <Input
                      id="businessEndDate"
                      type="date"
                      value={businessEndDate}
                      onChange={(e) => setBusinessEndDate(e.target.value)}
                    />
                  </div>
                </div>

                {businessDays > 0 && (
                  <div className="p-4 bg-muted rounded-lg">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-orange-600">
                        {businessDays}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Días laborables (sin sábados ni domingos)
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Current Date Info */}
            <Card>
              <CardHeader>
                <CardTitle>Información Actual</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span>Fecha actual:</span>
                    <span className="font-semibold">
                      {new Date().toLocaleDateString('es-ES')}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Día del año:</span>
                    <span className="font-semibold">
                      {Math.floor((new Date().getTime() - new Date(new Date().getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24))}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Semana del año:</span>
                    <span className="font-semibold">
                      {Math.ceil(Math.floor((new Date().getTime() - new Date(new Date().getFullYear(), 0, 0).getTime()) / (1000 * 60 * 60 * 24)) / 7)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Trimestre:</span>
                    <span className="font-semibold">
                      Q{Math.floor(new Date().getMonth() / 3) + 1}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Reset Button */}
        <div className="text-center mt-8">
          <Button onClick={resetAll} variant="outline">
            <RotateCcw className="mr-2 h-4 w-4" />
            Limpiar Todo
          </Button>
        </div>
      </motion.div>
    </div>
  )
}
