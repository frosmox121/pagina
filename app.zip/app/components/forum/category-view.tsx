

'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { 
  ArrowLeft, 
  MessageSquare, 
  Pin, 
  Lock, 
  Eye, 
  Clock, 
  Plus,
  User
} from 'lucide-react'
import { motion } from 'framer-motion'
import Link from 'next/link'

interface Topic {
  id: string
  title: string
  content: string
  category: {
    name: string
    color: string
  }
  author: {
    name: string
    image?: string
  }
  isPinned: boolean
  isLocked: boolean
  viewCount: number
  postCount: number
  lastPost: {
    author: {
      name: string
      image?: string
    }
    createdAt: string
  } | null
  createdAt: string
  updatedAt: string
}

interface CategoryViewProps {
  categoryId: string
}

export function CategoryView({ categoryId }: CategoryViewProps) {
  const [topics, setTopics] = useState<Topic[]>([])
  const [categoryName, setCategoryName] = useState('')
  const [categoryColor, setCategoryColor] = useState('#3B82F6')
  const [isLoading, setIsLoading] = useState(true)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)

  useEffect(() => {
    if (categoryId) {
      fetchTopics()
    }
  }, [categoryId, currentPage])

  const fetchTopics = async () => {
    try {
      setIsLoading(true)
      const response = await fetch(`/api/forum/topics?categoryId=${categoryId}&page=${currentPage}`)
      if (response.ok) {
        const data = await response.json()
        setTopics(data.topics || [])
        setTotalPages(data.pagination?.pages || 1)
        
        // Get category name from first topic
        if (data.topics.length > 0) {
          setCategoryName(data.topics[0].category.name)
          setCategoryColor(data.topics[0].category.color)
        }
      }
    } catch (error) {
      console.error('Error fetching topics:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60))
    
    if (diffInMinutes < 1) return 'Ahora'
    if (diffInMinutes < 60) return `Hace ${diffInMinutes}m`
    if (diffInMinutes < 1440) return `Hace ${Math.floor(diffInMinutes / 60)}h`
    return date.toLocaleDateString()
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Header */}
        <div className="mb-6">
          <Button variant="outline" asChild className="mb-4">
            <Link href="/forum">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Volver al Foro
            </Link>
          </Button>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div 
                className="w-6 h-6 rounded-full"
                style={{ backgroundColor: categoryColor }}
              />
              <div>
                <h1 className="text-3xl font-bold tracking-tight">{categoryName}</h1>
                <p className="text-muted-foreground">
                  {topics.length} tema{topics.length !== 1 ? 's' : ''} en esta categoría
                </p>
              </div>
            </div>
            <Button asChild>
              <Link href="/forum/create">
                <Plus className="mr-2 h-4 w-4" />
                Crear Tema
              </Link>
            </Button>
          </div>
        </div>

        {/* Topics List */}
        <div className="space-y-4">
          {topics.length === 0 ? (
            <Card>
              <CardContent className="text-center py-12">
                <MessageSquare className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-semibold mb-2">No hay temas aún</h3>
                <p className="text-muted-foreground mb-4">
                  Sé el primero en crear un tema en esta categoría
                </p>
                <Button asChild>
                  <Link href="/forum/create">
                    <Plus className="mr-2 h-4 w-4" />
                    Crear Primer Tema
                  </Link>
                </Button>
              </CardContent>
            </Card>
          ) : (
            topics.map((topic, index) => (
              <motion.div
                key={topic.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card className="hover:shadow-lg transition-shadow duration-300">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          {topic.isPinned && (
                            <Badge variant="secondary" className="text-xs">
                              <Pin className="mr-1 h-3 w-3" />
                              Fijado
                            </Badge>
                          )}
                          {topic.isLocked && (
                            <Badge variant="destructive" className="text-xs">
                              <Lock className="mr-1 h-3 w-3" />
                              Cerrado
                            </Badge>
                          )}
                        </div>
                        
                        <Link 
                          href={`/forum/topic/${topic.id}`}
                          className="block hover:text-primary transition-colors"
                        >
                          <h3 className="text-lg font-semibold mb-2 line-clamp-2">
                            {topic.title}
                          </h3>
                        </Link>
                        
                        <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
                          {topic.content}
                        </p>
                        
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <User className="h-3 w-3" />
                            <span>{topic.author.name}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <MessageSquare className="h-3 w-3" />
                            <span>{topic.postCount} respuestas</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Eye className="h-3 w-3" />
                            <span>{topic.viewCount} vistas</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            <span>Creado {formatDate(topic.createdAt)}</span>
                          </div>
                        </div>
                      </div>
                      
                      {topic.lastPost && (
                        <div className="text-right text-xs text-muted-foreground min-w-[120px]">
                          <div className="mb-1">Última respuesta</div>
                          <div className="font-medium">{topic.lastPost.author.name}</div>
                          <div>{formatDate(topic.lastPost.createdAt)}</div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))
          )}
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center gap-2 mt-8">
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
              <Button
                key={page}
                variant={currentPage === page ? "default" : "outline"}
                size="sm"
                onClick={() => setCurrentPage(page)}
              >
                {page}
              </Button>
            ))}
          </div>
        )}
      </motion.div>
    </div>
  )
}
