

'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Textarea } from '@/components/ui/textarea'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { 
  ArrowLeft, 
  MessageSquare, 
  Pin, 
  Lock, 
  Eye, 
  Clock, 
  Send,
  User,
  Medal,
  Calendar
} from 'lucide-react'
import { motion } from 'framer-motion'
import Link from 'next/link'
import { useToast } from '@/hooks/use-toast'

interface Topic {
  id: string
  title: string
  content: string
  category: {
    name: string
    color: string
  }
  author: {
    name: string
    image?: string
    level: number
    totalPoints: number
  }
  isPinned: boolean
  isLocked: boolean
  viewCount: number
  createdAt: string
  updatedAt: string
}

interface Post {
  id: string
  content: string
  author: {
    id: string
    name: string
    image?: string
    level: number
    totalPoints: number
    joinedAt: string
  }
  createdAt: string
  updatedAt: string
}

interface TopicViewProps {
  topicId: string
}

export function TopicView({ topicId }: TopicViewProps) {
  const { data: session } = useSession()
  const { toast } = useToast()
  const [topic, setTopic] = useState<Topic | null>(null)
  const [posts, setPosts] = useState<Post[]>([])
  const [newPostContent, setNewPostContent] = useState('')
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)

  useEffect(() => {
    if (topicId) {
      fetchTopic()
    }
  }, [topicId, currentPage])

  const fetchTopic = async () => {
    try {
      setIsLoading(true)
      const response = await fetch(`/api/forum/topics/${topicId}?page=${currentPage}`)
      if (response.ok) {
        const data = await response.json()
        setTopic(data.topic)
        setPosts(data.posts || [])
        setTotalPages(data.pagination?.pages || 1)
      } else {
        toast({
          title: "Error",
          description: "No se pudo cargar el tema",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error('Error fetching topic:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleSubmitPost = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!newPostContent.trim()) {
      toast({
        title: "Error",
        description: "El mensaje no puede estar vacío",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)
    
    try {
      const response = await fetch(`/api/forum/topics/${topicId}/posts`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          content: newPostContent.trim()
        }),
      })

      const data = await response.json()

      if (response.ok) {
        setPosts(prev => [...prev, data.post])
        setNewPostContent('')
        toast({
          title: "Mensaje enviado",
          description: "Tu respuesta ha sido publicada",
        })
      } else {
        toast({
          title: "Error",
          description: data.error || "No se pudo enviar el mensaje",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error('Error creating post:', error)
      toast({
        title: "Error",
        description: "Ocurrió un error al enviar el mensaje",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('es-ES', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const getTimeAgo = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60))
    
    if (diffInMinutes < 1) return 'Ahora'
    if (diffInMinutes < 60) return `Hace ${diffInMinutes}m`
    if (diffInMinutes < 1440) return `Hace ${Math.floor(diffInMinutes / 60)}h`
    if (diffInMinutes < 43200) return `Hace ${Math.floor(diffInMinutes / 1440)}d`
    return formatDate(dateString)
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!topic) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-4xl text-center">
        <h1 className="text-2xl font-bold mb-4">Tema no encontrado</h1>
        <Button asChild>
          <Link href="/forum">Volver al Foro</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        {/* Header */}
        <div className="mb-6">
          <Button variant="outline" asChild className="mb-4">
            <Link href="/forum">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Volver al Foro
            </Link>
          </Button>
        </div>

        {/* Topic Header */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-3">
                  <div 
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: topic.category.color }}
                  />
                  <Badge variant="outline">{topic.category.name}</Badge>
                  {topic.isPinned && (
                    <Badge variant="secondary">
                      <Pin className="mr-1 h-3 w-3" />
                      Fijado
                    </Badge>
                  )}
                  {topic.isLocked && (
                    <Badge variant="destructive">
                      <Lock className="mr-1 h-3 w-3" />
                      Cerrado
                    </Badge>
                  )}
                </div>
                <CardTitle className="text-2xl mb-4">{topic.title}</CardTitle>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <User className="h-4 w-4" />
                    <span>{topic.author.name}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Eye className="h-4 w-4" />
                    <span>{topic.viewCount} vistas</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    <span>{getTimeAgo(topic.createdAt)}</span>
                  </div>
                </div>
              </div>
            </div>
          </CardHeader>
        </Card>

        {/* Original Post */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <Avatar className="h-12 w-12">
                  <AvatarImage src={topic.author.image} />
                  <AvatarFallback>
                    {topic.author.name.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="font-semibold">{topic.author.name}</span>
                  <Badge variant="outline" className="text-xs">
                    <Medal className="mr-1 h-3 w-3" />
                    Nivel {topic.author.level}
                  </Badge>
                  <span className="text-xs text-muted-foreground">
                    {topic.author.totalPoints} puntos
                  </span>
                </div>
                <div className="prose prose-sm max-w-none dark:prose-invert">
                  <p className="whitespace-pre-wrap">{topic.content}</p>
                </div>
                <div className="flex items-center gap-2 mt-4 text-xs text-muted-foreground">
                  <Clock className="h-3 w-3" />
                  <span>Publicado {formatDate(topic.createdAt)}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Posts */}
        <div className="space-y-4 mb-6">
          {posts.map((post, index) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card>
                <CardContent className="p-6">
                  <div className="flex gap-4">
                    <div className="flex-shrink-0">
                      <Link href={`/profile/${post.author.id}`}>
                        <Avatar className="h-10 w-10 hover:ring-2 hover:ring-primary transition-all">
                          <AvatarImage src={post.author.image} />
                          <AvatarFallback>
                            {post.author.name.charAt(0).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                      </Link>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Link 
                          href={`/profile/${post.author.id}`}
                          className="font-semibold hover:text-primary transition-colors"
                        >
                          {post.author.name}
                        </Link>
                        <Badge variant="outline" className="text-xs">
                          <Medal className="mr-1 h-3 w-3" />
                          Nivel {post.author.level}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {post.author.totalPoints} puntos
                        </span>
                        <span className="text-xs text-muted-foreground">
                          • Miembro desde {new Date(post.author.joinedAt).getFullYear()}
                        </span>
                      </div>
                      <div className="prose prose-sm max-w-none dark:prose-invert">
                        <p className="whitespace-pre-wrap">{post.content}</p>
                      </div>
                      <div className="flex items-center gap-2 mt-4 text-xs text-muted-foreground">
                        <Clock className="h-3 w-3" />
                        <span>{getTimeAgo(post.createdAt)}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center gap-2 mb-6">
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
              <Button
                key={page}
                variant={currentPage === page ? "default" : "outline"}
                size="sm"
                onClick={() => setCurrentPage(page)}
              >
                {page}
              </Button>
            ))}
          </div>
        )}

        {/* Reply Form */}
        {!topic.isLocked && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Responder al tema</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmitPost} className="space-y-4">
                <Textarea
                  placeholder="Escribe tu respuesta..."
                  value={newPostContent}
                  onChange={(e) => setNewPostContent(e.target.value)}
                  rows={6}
                  maxLength={2000}
                />
                <div className="flex justify-between items-center">
                  <div className="text-xs text-muted-foreground">
                    {newPostContent.length}/2000 caracteres
                  </div>
                  <Button 
                    type="submit" 
                    disabled={isSubmitting || !newPostContent.trim()}
                  >
                    {isSubmitting ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Enviando...
                      </>
                    ) : (
                      <>
                        <Send className="mr-2 h-4 w-4" />
                        Responder
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}
      </motion.div>
    </div>
  )
}
