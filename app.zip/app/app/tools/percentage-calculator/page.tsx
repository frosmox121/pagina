

import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { PercentageCalculator } from '@/components/tools/percentage-calculator'

export default async function PercentageCalculatorPage() {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    redirect('/auth/login')
  }

  return <PercentageCalculator />
}
