

import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { TextAnalyzer } from '@/components/tools/text-analyzer'

export default async function TextAnalyzerPage() {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    redirect('/auth/login')
  }

  return <TextAnalyzer />
}
