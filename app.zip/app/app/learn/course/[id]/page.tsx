
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { CoursePage } from '@/components/learn/course-page'

interface CoursePageProps {
  params: {
    id: string
  }
}

export default async function IndividualCoursePage({ params }: CoursePageProps) {
  const session = await getServerSession(authOptions)

  if (!session?.user) {
    redirect('/auth/login')
  }

  return <CoursePage courseId={params.id} />
}
