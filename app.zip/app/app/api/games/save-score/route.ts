
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { NextRequest } from 'next/server'

export const dynamic = 'force-dynamic'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return new Response(JSON.stringify({ error: 'No autorizado' }), {
        status: 401,
      })
    }

    const { gameType, score, level, duration } = await request.json()

    if (!gameType || score === undefined) {
      return new Response(JSON.stringify({ error: 'Datos incompletos' }), {
        status: 400,
      })
    }

    // Validate game type
    const validGameTypes = ['snake', 'tetris', 'pong', 'memory', '2048']
    if (!validGameTypes.includes(gameType)) {
      return new Response(JSON.stringify({ error: 'Tipo de juego inválido' }), {
        status: 400,
      })
    }

    // Save the game score
    const gameScore = await prisma.gameScore.create({
      data: {
        userId: session.user.id,
        gameType,
        score: parseInt(score),
        level: level ? parseInt(level) : null,
        duration: duration ? parseInt(duration) : null
      }
    })

    // Update user's total points based on game performance
    let pointsToAdd = 0
    
    switch (gameType) {
      case 'snake':
        pointsToAdd = Math.floor(score / 10) // 1 point per 10 score points
        break
      case 'tetris':
        pointsToAdd = Math.floor(score / 100) // 1 point per 100 score points
        break
      case 'pong':
        pointsToAdd = score * 5 // 5 points per pong score
        break
      case 'memory':
        pointsToAdd = Math.floor(score / 5) // 1 point per 5 score points (memory is skill-based)
        break
      case '2048':
        pointsToAdd = Math.floor(score / 200) // 1 point per 200 score points (2048 scores are very high)
        break
    }

    if (pointsToAdd > 0) {
      await prisma.user.update({
        where: { id: session.user.id },
        data: {
          totalPoints: {
            increment: pointsToAdd
          }
        }
      })

      // Update user level based on total points
      const updatedUser = await prisma.user.findUnique({
        where: { id: session.user.id },
        select: { totalPoints: true }
      })

      if (updatedUser) {
        const newLevel = Math.floor(updatedUser.totalPoints / 100) + 1
        await prisma.user.update({
          where: { id: session.user.id },
          data: { level: newLevel }
        })
      }
    }

    return new Response(JSON.stringify({
      success: true,
      gameScore: {
        id: gameScore.id,
        score: gameScore.score,
        level: gameScore.level,
        pointsEarned: pointsToAdd
      }
    }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
      },
    })

  } catch (error) {
    console.error('Save score API error:', error)
    return new Response(JSON.stringify({ 
      error: 'Error interno del servidor' 
    }), {
      status: 500,
    })
  }
}
