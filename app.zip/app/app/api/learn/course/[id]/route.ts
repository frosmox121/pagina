
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return new Response(JSON.stringify({ error: 'Not authenticated' }), {
        status: 401,
      })
    }

    const course = await prisma.course.findUnique({
      where: { id: params.id },
      include: {
        modules: {
          where: { isActive: true },
          orderBy: { orderIndex: 'asc' }
        },
        userProgress: {
          where: { userId: session.user.id }
        }
      }
    })

    if (!course) {
      return new Response(JSON.stringify({ error: 'Course not found' }), {
        status: 404,
      })
    }

    const userProgress = course.userProgress[0]
    const completedModules = userProgress?.completedModules as string[] || []

    const courseWithProgress = {
      id: course.id,
      title: course.title,
      description: course.description,
      language: course.language,
      difficulty: course.difficulty,
      imageUrl: course.imageUrl,
      progress: userProgress?.progress || 0,
      isEnrolled: !!userProgress,
      modules: course.modules.map(module => ({
        id: module.id,
        title: module.title,
        content: module.content,
        videoUrl: module.videoUrl,
        orderIndex: module.orderIndex,
        isCompleted: completedModules.includes(module.id)
      }))
    }

    return new Response(JSON.stringify({
      course: courseWithProgress
    }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
      },
    })

  } catch (error) {
    console.error('Course API error:', error)
    return new Response(JSON.stringify({ 
      error: 'Internal server error' 
    }), {
      status: 500,
    })
  }
}
