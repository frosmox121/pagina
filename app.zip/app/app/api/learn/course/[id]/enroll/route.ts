
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { createActivity } from '@/lib/activity'

export const dynamic = 'force-dynamic'

export async function POST(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return new Response(JSON.stringify({ error: 'Not authenticated' }), {
        status: 401,
      })
    }

    // Check if course exists
    const course = await prisma.course.findUnique({
      where: { id: params.id }
    })

    if (!course) {
      return new Response(JSON.stringify({ error: 'Course not found' }), {
        status: 404,
      })
    }

    // Check if already enrolled
    const existingProgress = await prisma.userProgress.findUnique({
      where: {
        userId_courseId: {
          userId: session.user.id,
          courseId: params.id
        }
      }
    })

    if (existingProgress) {
      return new Response(JSON.stringify({ error: 'Already enrolled' }), {
        status: 400,
      })
    }

    // Create enrollment
    await prisma.userProgress.create({
      data: {
        userId: session.user.id,
        courseId: params.id,
        progress: 0,
        completedModules: []
      }
    })

    // Create activity
    await createActivity({
      userId: session.user.id,
      type: 'course_started',
      title: `Te inscribiste en "${course.title}"`,
      description: 'Comenzaste un nuevo curso de aprendizaje',
      metadata: {
        courseId: course.id,
        courseTitle: course.title,
        language: course.language
      }
    })

    return new Response(JSON.stringify({
      success: true
    }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
      },
    })

  } catch (error) {
    console.error('Course enrollment API error:', error)
    return new Response(JSON.stringify({ 
      error: 'Internal server error' 
    }), {
      status: 500,
    })
  }
}
