
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return new Response(JSON.stringify({ error: 'Not authenticated' }), {
        status: 401,
      })
    }

    // Get total courses
    const totalCourses = await prisma.course.count({
      where: { isActive: true }
    })

    // Get user's enrolled courses
    const userProgress = await prisma.userProgress.findMany({
      where: { userId: session.user.id }
    })

    const enrolledCourses = userProgress.length
    const completedCourses = userProgress.filter(up => up.progress >= 100).length

    // Calculate total study hours (mock calculation)
    const totalHours = enrolledCourses * 2 // Assume 2 hours per enrolled course

    // Calculate certificates (completed courses)
    const certificates = completedCourses

    // Calculate rank based on completed courses
    const usersWithMoreCompletedCourses = await prisma.userProgress.groupBy({
      by: ['userId'],
      _count: { userId: true },
      where: { progress: { gte: 100 } }
    }).then(results => 
      results.filter(result => result._count.userId > completedCourses)
    )
    const rank = usersWithMoreCompletedCourses.length + 1

    return new Response(JSON.stringify({
      stats: {
        totalCourses,
        enrolledCourses,
        completedCourses,
        totalHours,
        certificates,
        rank
      }
    }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
      },
    })

  } catch (error) {
    console.error('Learning stats API error:', error)
    return new Response(JSON.stringify({ 
      error: 'Internal server error' 
    }), {
      status: 500,
    })
  }
}
