
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return new Response(JSON.stringify({ error: 'Not authenticated' }), {
        status: 401,
      })
    }

    // Fetch all active courses with module count
    const courses = await prisma.course.findMany({
      where: { isActive: true },
      include: {
        modules: {
          where: { isActive: true },
          select: { id: true }
        },
        userProgress: {
          where: { userId: session.user.id },
          select: { progress: true }
        }
      },
      orderBy: { orderIndex: 'asc' }
    })

    const coursesWithProgress = courses.map(course => ({
      id: course.id,
      title: course.title,
      description: course.description,
      language: course.language,
      difficulty: course.difficulty,
      imageUrl: course.imageUrl,
      orderIndex: course.orderIndex,
      isActive: course.isActive,
      modules: course.modules.length,
      progress: course.userProgress[0]?.progress || 0,
      isEnrolled: course.userProgress.length > 0
    }))

    return new Response(JSON.stringify({
      courses: coursesWithProgress
    }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
      },
    })

  } catch (error) {
    console.error('Courses API error:', error)
    return new Response(JSON.stringify({ 
      error: 'Internal server error' 
    }), {
      status: 500,
    })
  }
}
