
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { NextRequest } from 'next/server'

export const dynamic = 'force-dynamic'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return new Response(JSON.stringify({ error: 'No autorizado' }), {
        status: 401,
      })
    }

    const { code, language } = await request.json()

    if (!code || !language) {
      return new Response(JSON.stringify({ error: 'Código y lenguaje son requeridos' }), {
        status: 400,
      })
    }

    // Prepare language-specific execution prompt
    const languageMap: { [key: string]: string } = {
      'python': 'Python',
      'csharp': 'C#',
      'cpp': 'C++'
    }

    const languageName = languageMap[language] || language

    const prompt = `Actúa como un ejecutor de código ${languageName}. Ejecuta el siguiente código y proporciona la salida exacta que se mostraría en una consola real. 

REGLAS IMPORTANTES:
1. Ejecuta el código exactamente como se proporcionó
2. Muestra SOLO la salida del programa (lo que aparecería en stdout)
3. Si hay errores, muestra el mensaje de error completo
4. No agregues explicaciones adicionales, solo la salida
5. Si el código imprime múltiples líneas, muestra cada línea
6. Mantén el formato original de la salida

Código a ejecutar:
\`\`\`${language}
${code}
\`\`\`

Salida:`

    // Create streaming response
    const encoder = new TextEncoder()
    const readable = new ReadableStream({
      async start(controller) {
        try {
          const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${process.env.ABACUSAI_API_KEY}`
            },
            body: JSON.stringify({
              model: 'gpt-4.1-mini',
              messages: [
                {
                  role: 'user',
                  content: prompt
                }
              ],
              stream: true,
              max_tokens: 2000,
              temperature: 0.1
            }),
          })

          if (!response.ok) {
            throw new Error(`API Error: ${response.status}`)
          }

          const reader = response.body?.getReader()
          if (!reader) {
            throw new Error('No response body')
          }

          const decoder = new TextDecoder()
          let buffer = ''

          while (true) {
            const { done, value } = await reader.read()
            if (done) break

            const chunk = decoder.decode(value, { stream: true })
            buffer += chunk

            const lines = buffer.split('\n')
            buffer = lines.pop() || ''

            for (const line of lines) {
              if (line.startsWith('data: ')) {
                const data = line.slice(6)
                if (data === '[DONE]') {
                  controller.enqueue(encoder.encode('data: [DONE]\n\n'))
                  controller.close()
                  return
                }

                try {
                  const parsed = JSON.parse(data)
                  const content = parsed.choices?.[0]?.delta?.content || ''
                  if (content) {
                    controller.enqueue(encoder.encode(`data: ${JSON.stringify({content})}\n\n`))
                  }
                } catch (e) {
                  // Skip invalid JSON
                }
              }
            }
          }

          controller.enqueue(encoder.encode('data: [DONE]\n\n'))
          controller.close()
        } catch (error) {
          console.error('Code execution error:', error)
          controller.enqueue(encoder.encode(`data: ${JSON.stringify({content: `Error: No se pudo ejecutar el código. ${error instanceof Error ? error.message : 'Error desconocido'}`})}\n\n`))
          controller.enqueue(encoder.encode('data: [DONE]\n\n'))
          controller.close()
        }
      }
    })

    return new Response(readable, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    })

  } catch (error) {
    console.error('Code execution route error:', error)
    return new Response(JSON.stringify({ 
      error: 'Error interno del servidor' 
    }), {
      status: 500,
    })
  }
}
