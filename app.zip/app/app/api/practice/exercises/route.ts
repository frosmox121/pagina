
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return new Response(JSON.stringify({ error: 'No autorizado' }), {
        status: 401,
      })
    }

    // Fetch all exercises
    const exercises = await prisma.exercise.findMany({
      where: {
        isActive: true
      },
      orderBy: [
        { difficulty: 'asc' },
        { points: 'asc' },
        { title: 'asc' }
      ]
    })

    // Get user's submissions to determine completed exercises
    const userSubmissions = await prisma.submission.findMany({
      where: {
        userId: session.user.id,
        status: 'passed'
      },
      select: {
        exerciseId: true,
        score: true
      }
    })

    // Create a map of completed exercises
    const completedMap = new Map(
      userSubmissions.map(submission => [
        submission.exerciseId, 
        submission.score
      ])
    )

    // Enhance exercises with completion status
    const enhancedExercises = exercises.map(exercise => ({
      id: exercise.id,
      title: exercise.title,
      description: exercise.description,
      language: exercise.language,
      difficulty: exercise.difficulty,
      points: exercise.points,
      category: exercise.category,
      isCompleted: completedMap.has(exercise.id),
      userScore: completedMap.get(exercise.id) || undefined
    }))

    return new Response(JSON.stringify({
      exercises: enhancedExercises,
      total: enhancedExercises.length
    }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
      },
    })

  } catch (error) {
    console.error('Exercises API error:', error)
    return new Response(JSON.stringify({ 
      error: 'Error interno del servidor' 
    }), {
      status: 500,
    })
  }
}
