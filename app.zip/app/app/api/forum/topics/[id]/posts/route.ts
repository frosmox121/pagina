

import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { NextRequest } from 'next/server'

export const dynamic = 'force-dynamic'

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return new Response(JSON.stringify({ error: 'Not authenticated' }), {
        status: 401,
      })
    }

    const { content } = await request.json()

    if (!content || content.trim().length === 0) {
      return new Response(JSON.stringify({ error: 'Content is required' }), {
        status: 400,
      })
    }

    // Check if topic exists and is not locked
    const topic = await prisma.forumTopic.findUnique({
      where: { id: params.id }
    })

    if (!topic) {
      return new Response(JSON.stringify({ error: 'Topic not found' }), {
        status: 404,
      })
    }

    if (topic.isLocked) {
      return new Response(JSON.stringify({ error: 'Topic is locked' }), {
        status: 403,
      })
    }

    // Anti-spam: Check if user has posted recently
    const recentPost = await prisma.forumPost.findFirst({
      where: {
        authorId: session.user.id,
        createdAt: {
          gte: new Date(Date.now() - 30 * 1000) // 30 seconds
        }
      }
    })

    if (recentPost) {
      return new Response(JSON.stringify({ 
        error: 'Debes esperar 30 segundos entre mensajes para evitar spam' 
      }), {
        status: 429,
      })
    }

    const post = await prisma.forumPost.create({
      data: {
        content,
        topicId: params.id,
        authorId: session.user.id
      },
      include: {
        author: {
          select: { 
            id: true,
            name: true, 
            image: true, 
            level: true, 
            totalPoints: true,
            joinedAt: true
          }
        }
      }
    })

    // Update topic's updatedAt
    await prisma.forumTopic.update({
      where: { id: params.id },
      data: { updatedAt: new Date() }
    })

    return new Response(JSON.stringify({
      post: {
        id: post.id,
        content: post.content,
        author: {
          ...post.author,
          joinedAt: post.author.joinedAt.toISOString()
        },
        createdAt: post.createdAt.toISOString(),
        updatedAt: post.updatedAt.toISOString()
      }
    }), {
      status: 201,
      headers: {
        'Content-Type': 'application/json',
      },
    })

  } catch (error) {
    console.error('Create post API error:', error)
    return new Response(JSON.stringify({ 
      error: 'Internal server error' 
    }), {
      status: 500,
    })
  }
}
