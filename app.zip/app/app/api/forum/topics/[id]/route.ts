

import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { NextRequest } from 'next/server'

export const dynamic = 'force-dynamic'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return new Response(JSON.stringify({ error: 'Not authenticated' }), {
        status: 401,
      })
    }

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const offset = (page - 1) * limit

    // Get topic with posts
    const topic = await prisma.forumTopic.findUnique({
      where: { id: params.id },
      include: {
        category: {
          select: { name: true, color: true }
        },
        author: {
          select: { name: true, image: true, level: true, totalPoints: true }
        },
        posts: {
          skip: offset,
          take: limit,
          orderBy: { createdAt: 'asc' },
          include: {
            author: {
              select: { 
                id: true,
                name: true, 
                image: true, 
                level: true, 
                totalPoints: true,
                joinedAt: true
              }
            }
          }
        },
        _count: {
          select: { posts: true }
        }
      }
    })

    if (!topic) {
      return new Response(JSON.stringify({ error: 'Topic not found' }), {
        status: 404,
      })
    }

    // Increment view count
    await prisma.forumTopic.update({
      where: { id: params.id },
      data: { viewCount: { increment: 1 } }
    })

    const totalPosts = topic._count.posts

    return new Response(JSON.stringify({
      topic: {
        id: topic.id,
        title: topic.title,
        content: topic.content,
        category: topic.category,
        author: topic.author,
        isPinned: topic.isPinned,
        isLocked: topic.isLocked,
        viewCount: topic.viewCount + 1,
        createdAt: topic.createdAt.toISOString(),
        updatedAt: topic.updatedAt.toISOString()
      },
      posts: topic.posts.map(post => ({
        id: post.id,
        content: post.content,
        author: {
          ...post.author,
          joinedAt: post.author.joinedAt.toISOString()
        },
        createdAt: post.createdAt.toISOString(),
        updatedAt: post.updatedAt.toISOString()
      })),
      pagination: {
        page,
        limit,
        total: totalPosts,
        pages: Math.ceil(totalPosts / limit)
      }
    }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
      },
    })

  } catch (error) {
    console.error('Topic API error:', error)
    return new Response(JSON.stringify({ 
      error: 'Internal server error' 
    }), {
      status: 500,
    })
  }
}
