

import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return new Response(JSON.stringify({ error: 'Not authenticated' }), {
        status: 401,
      })
    }

    const categories = await prisma.forumCategory.findMany({
      where: { isActive: true },
      orderBy: { orderIndex: 'asc' },
      include: {
        topics: {
          take: 3,
          orderBy: { updatedAt: 'desc' },
          include: {
            author: {
              select: { name: true, image: true }
            },
            _count: {
              select: { posts: true }
            }
          }
        },
        _count: {
          select: { topics: true }
        }
      }
    })

    return new Response(JSON.stringify({
      categories: categories.map(category => ({
        id: category.id,
        name: category.name,
        description: category.description,
        color: category.color,
        topicCount: category._count.topics,
        recentTopics: category.topics.map(topic => ({
          id: topic.id,
          title: topic.title,
          author: topic.author.name,
          authorImage: topic.author.image,
          postCount: topic._count.posts,
          updatedAt: topic.updatedAt.toISOString()
        }))
      }))
    }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
      },
    })

  } catch (error) {
    console.error('Forum categories API error:', error)
    return new Response(JSON.stringify({ 
      error: 'Internal server error' 
    }), {
      status: 500,
    })
  }
}
