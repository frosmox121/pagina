

import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user) {
      return new Response(JSON.stringify({ error: 'Not authenticated' }), {
        status: 401,
      })
    }

    const user = await prisma.user.findUnique({
      where: { id: params.id },
      select: {
        id: true,
        name: true,
        image: true,
        email: session.user.id === params.id, // Only show email to self
        level: true,
        totalPoints: true,
        practicePoints: true,
        country: true,
        joinedAt: true,
        lastActive: true,
        preferences: {
          select: {
            profilePublic: true
          }
        },
        _count: {
          select: {
            forumTopics: true,
            forumPosts: true,
            gameScores: true,
            userAchievements: true,
            submissions: true
          }
        }
      }
    })

    if (!user) {
      return new Response(JSON.stringify({ error: 'User not found' }), {
        status: 404,
      })
    }

    // Check if profile is public (unless it's the user's own profile)
    if (session.user.id !== params.id && !user.preferences?.profilePublic) {
      return new Response(JSON.stringify({ error: 'Profile is private' }), {
        status: 403,
      })
    }

    // Calculate user ranking
    const usersWithMorePoints = await prisma.user.count({
      where: {
        totalPoints: {
          gt: user.totalPoints
        }
      }
    })
    const rank = usersWithMorePoints + 1

    // Get recent forum activity
    const recentTopics = await prisma.forumTopic.findMany({
      where: { authorId: params.id },
      take: 5,
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        title: true,
        createdAt: true,
        category: {
          select: { name: true, color: true }
        }
      }
    })

    // Get recent achievements
    const recentAchievements = await prisma.userAchievement.findMany({
      where: { userId: params.id },
      take: 5,
      orderBy: { unlockedAt: 'desc' },
      include: {
        achievement: {
          select: {
            title: true,
            description: true,
            icon: true,
            rarity: true
          }
        }
      }
    })

    return new Response(JSON.stringify({
      user: {
        id: user.id,
        name: user.name,
        image: user.image,
        email: user.email,
        level: user.level,
        totalPoints: user.totalPoints,
        practicePoints: user.practicePoints,
        country: user.country,
        rank,
        joinedAt: user.joinedAt.toISOString(),
        lastActive: user.lastActive.toISOString(),
        stats: {
          forumTopics: user._count.forumTopics,
          forumPosts: user._count.forumPosts,
          gamesPlayed: user._count.gameScores,
          achievements: user._count.userAchievements,
          exercisesCompleted: user._count.submissions
        },
        recentActivity: {
          topics: recentTopics.map(topic => ({
            id: topic.id,
            title: topic.title,
            category: topic.category,
            createdAt: topic.createdAt.toISOString()
          })),
          achievements: recentAchievements.map(ua => ({
            id: ua.id,
            achievement: ua.achievement,
            unlockedAt: ua.unlockedAt.toISOString()
          }))
        }
      }
    }), {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
      },
    })

  } catch (error) {
    console.error('User profile API error:', error)
    return new Response(JSON.stringify({ 
      error: 'Internal server error' 
    }), {
      status: 500,
    })
  }
}
