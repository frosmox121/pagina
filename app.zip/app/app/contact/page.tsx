
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { ContactForm } from '@/components/contact-form'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Mail, MapPin, User } from 'lucide-react'

export default async function ContactPage() {
  const session = await getServerSession(authOptions)

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight mb-4">
          📧 Contacto
        </h1>
        <p className="text-lg text-muted-foreground">
          ¿Tienes alguna pregunta o sugerencia? ¡Nos encantaría escucharte!
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Contact Form */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Enviar Mensaje</CardTitle>
              <CardDescription>
                Completa el formulario y nos pondremos en contacto contigo pronto
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ContactForm />
            </CardContent>
          </Card>
        </div>

        {/* Contact Info */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Información de Contacto</CardTitle>
              <CardDescription>
                Otras formas de ponerte en contacto con nosotros
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <Mail className="h-5 w-5 text-blue-500" />
                </div>
                <div>
                  <p className="font-medium">Email</p>
                  <p className="text-muted-foreground">zzzfaze99@gmail.com</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-green-500/10 flex items-center justify-center">
                  <User className="h-5 w-5 text-green-500" />
                </div>
                <div>
                  <p className="font-medium">Desarrollador</p>
                  <p className="text-muted-foreground">Agustín</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
                  <MapPin className="h-5 w-5 text-purple-500" />
                </div>
                <div>
                  <p className="font-medium">Ubicación</p>
                  <p className="text-muted-foreground">Argentina 🇦🇷</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>¿Por qué contactarnos?</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-muted-foreground">
                <li>• Reportar bugs o problemas</li>
                <li>• Sugerir nuevas funcionalidades</li>
                <li>• Solicitar ayuda técnica</li>
                <li>• Colaborar en el proyecto</li>
                <li>• Consultas generales</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
